import React, { useState } from 'react';
import { 
  X, 
  User as UserIcon, 
  Phone, 
  MapPin, 
  LogOut, 
  PlusCircle, 
  Sparkles, 
  Edit3, 
  Trash2, 
  Clock,
  CheckCircle,
  Tag,
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';
import { User, Ad } from '../types';
import { formatPrice, formatTimeAgo } from '../utils/storage';

interface MyAccountModalProps {
  user: User | null;
  isOpen: boolean;
  onClose: () => void;
  onLogout: () => void;
  userAds: Ad[];
  onOpenAddAd: () => void;
  onEditAd: (ad: Ad) => void;
  onDeleteAd: (adId: string) => void;
  onPromoteAd: (adId: string) => void;
  promoPrice: number;
}

export const MyAccountModal: React.FC<MyAccountModalProps> = ({
  user,
  isOpen,
  onClose,
  onLogout,
  userAds,
  onOpenAddAd,
  onEditAd,
  onDeleteAd,
  onPromoteAd,
  promoPrice,
}) => {
  if (!isOpen || !user) return null;

  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [promoteConfirmId, setPromoteConfirmId] = useState<string | null>(null);

  const approvedAdsCount = userAds.filter((a) => a.status === 'approved').length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div 
        className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[90vh] border border-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="bg-[#002f34] text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-[#23e5db] text-[#002f34] flex items-center justify-center font-black text-xl">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-black">{user.name}</h2>
                {approvedAdsCount >= 3 && (
                  <span className="text-[11px] font-bold bg-emerald-500 text-white px-2 py-0.5 rounded-full flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    Vânzător Verificat
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-300 font-medium mt-0.5">
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-[#23e5db]" />
                  {user.phone}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-[#23e5db]" />
                  {user.city}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-300 hover:text-white rounded-lg cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Action bar inside account */}
        <div className="bg-slate-100 px-5 py-3 flex items-center justify-between border-b border-slate-200">
          <div className="text-sm font-bold text-slate-800 flex items-center gap-2">
            <Tag className="w-4 h-4 text-[#002f34]" />
            <span>Anunțurile mele ({userAds.length})</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onOpenAddAd();
              }}
              className="bg-[#23e5db] hover:bg-[#3bf5eb] text-[#002f34] font-black text-xs sm:text-sm px-3.5 py-1.5 rounded-lg flex items-center gap-1.5 shadow-xs cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Adaugă anunț nou</span>
            </button>

            <button
              onClick={onLogout}
              className="text-xs text-rose-600 hover:text-rose-800 font-bold px-3 py-1.5 rounded-lg border border-rose-200 hover:bg-rose-50 flex items-center gap-1 cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Ieși din cont</span>
            </button>
          </div>
        </div>

        {/* Ads List Content */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          {userAds.length > 0 ? (
            userAds.map((ad) => (
              <div
                key={ad.id}
                className="bg-white rounded-xl border-2 border-slate-200 hover:border-slate-300 p-4 flex flex-col sm:flex-row items-stretch gap-4 transition"
              >
                {/* Image */}
                <div className="w-full sm:w-36 h-28 rounded-lg overflow-hidden bg-slate-100 shrink-0 relative">
                  <img
                    src={ad.images[0] || 'https://images.unsplash.com/photo-1584824486509-112e4181ff6b?w=800&auto=format&fit=crop&q=80'}
                    alt={ad.title}
                    className="w-full h-full object-cover"
                  />
                  {ad.status === 'pending' && (
                    <span className="absolute top-1.5 left-1.5 bg-amber-500 text-slate-950 text-[10px] font-black uppercase px-2 py-0.5 rounded shadow">
                      ⏳ În așteptare
                    </span>
                  )}
                  {ad.isPromoted && (
                    <span className="absolute top-1.5 left-1.5 bg-[#002f34] text-[#23e5db] text-[10px] font-black uppercase px-2 py-0.5 rounded shadow">
                      ★ Promovat
                    </span>
                  )}
                </div>

                {/* Info */}
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-bold text-slate-900 text-base line-clamp-1">
                        {ad.title}
                      </h4>
                      <span className="font-black text-slate-900 text-base shrink-0">
                        {formatPrice(ad.price, ad.currency, ad.isFree)}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mt-1">
                      <span>{ad.category}</span>
                      <span>•</span>
                      <span>{ad.city}{ad.neighborhood ? `, ${ad.neighborhood}` : ''}</span>
                      <span>•</span>
                      <span>{formatTimeAgo(ad.createdAt)}</span>
                    </div>

                    {/* Status explanation */}
                    <div className="mt-1.5">
                      {ad.status === 'pending' ? (
                        <span className="text-xs font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 inline-flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          În așteptare aprobare de către administrator
                        </span>
                      ) : (
                        <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 inline-flex items-center gap-1">
                          <CheckCircle className="w-3.5 h-3.5" />
                          Aprobat și activ pe site
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions Row */}
                  <div className="pt-3 border-t border-slate-100 mt-3 flex flex-wrap items-center justify-between gap-2">
                    
                    {/* Promote button */}
                    {ad.status === 'approved' && !ad.isPromoted && (
                      promoteConfirmId === ad.id ? (
                        <div className="flex items-center gap-2 bg-amber-50 p-1.5 rounded-lg border border-amber-200">
                          <span className="text-xs text-amber-900 font-bold">
                            Cost: {promoPrice} lei. Confirmi?
                          </span>
                          <button
                            onClick={() => {
                              onPromoteAd(ad.id);
                              setPromoteConfirmId(null);
                            }}
                            className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded font-bold text-xs"
                          >
                            Plătește
                          </button>
                          <button
                            onClick={() => setPromoteConfirmId(null)}
                            className="px-2 py-1 text-slate-600 hover:text-slate-800 text-xs"
                          >
                            Anulează
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setPromoteConfirmId(ad.id)}
                          className="flex items-center gap-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 text-white font-black text-xs px-3 py-1.5 rounded-lg shadow-xs cursor-pointer active:scale-95"
                        >
                          <Sparkles className="w-3.5 h-3.5 text-yellow-200" />
                          <span>Promovează ({promoPrice} lei)</span>
                        </button>
                      )
                    )}

                    {ad.isPromoted && (
                      <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200 flex items-center gap-1">
                        <CheckCircle className="w-3.5 h-3.5" />
                        Anunț Promovat activ
                      </span>
                    )}

                    {/* Edit & Delete */}
                    <div className="flex items-center gap-2 ml-auto">
                      <button
                        onClick={() => onEditAd(ad)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-100 text-xs font-bold transition cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>Editează</span>
                      </button>

                      {deleteConfirmId === ad.id ? (
                        <div className="flex items-center gap-1 bg-rose-50 p-1 rounded border border-rose-200">
                          <span className="text-xs text-rose-700 font-bold">Sigur?</span>
                          <button
                            onClick={() => {
                              onDeleteAd(ad.id);
                              setDeleteConfirmId(null);
                            }}
                            className="px-2 py-0.5 bg-rose-600 text-white font-bold text-xs rounded"
                          >
                            Șterge
                          </button>
                          <button
                            onClick={() => setDeleteConfirmId(null)}
                            className="px-1 text-xs text-slate-600"
                          >
                            X
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setDeleteConfirmId(ad.id)}
                          className="flex items-center gap-1 px-3 py-1.5 rounded-lg border border-rose-200 text-rose-600 hover:bg-rose-50 text-xs font-bold transition cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Șterge</span>
                        </button>
                      )}
                    </div>

                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-12 px-4 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
              <Tag className="w-12 h-12 text-slate-300 mx-auto mb-2" />
              <h4 className="font-bold text-slate-800 text-base">Nu ai adăugat încă niciun anunț</h4>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                Vinde rapid orice produs sau serviciu în Pitești, Mioveni sau Curtea de Argeș.
              </p>
              <button
                onClick={() => {
                  onClose();
                  onOpenAddAd();
                }}
                className="mt-4 px-5 py-2.5 bg-[#002f34] text-white font-bold text-xs rounded-xl shadow cursor-pointer inline-flex items-center gap-1.5"
              >
                <PlusCircle className="w-4 h-4 text-[#23e5db]" />
                <span>Adaugă primul tău anunț gratis</span>
              </button>
            </div>
          )}
        </div>

        {/* Bottom bar */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 text-xs text-slate-500 flex items-center justify-between">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            Cont protejat de sistemul Anti-Țeapă Pitești Bazar
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-lg text-xs cursor-pointer"
          >
            Închide
          </button>
        </div>
      </div>
    </div>
  );
};
