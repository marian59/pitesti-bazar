import React, { useState } from 'react';
import { 
  X, 
  Phone, 
  Lock, 
  User as UserIcon, 
  MapPin, 
  CheckCircle2, 
  AlertCircle, 
  MessageSquare, 
  ArrowRight,
  ShieldAlert,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { User, LocationCity } from '../types';
import { CITIES } from '../data/seedAds';
import { getStoredUsers, saveStoredUsers, setCurrentUser, cleanPhone, isPhoneBlacklisted } from '../utils/storage';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
  initialMode?: 'login' | 'register';
  promptReason?: string;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess,
  initialMode = 'login',
  promptReason,
}) => {
  if (!isOpen) return null;

  const [mode, setMode] = useState<'login' | 'register'>(initialMode);
  
  // Login fields
  const [loginPhone, setLoginPhone] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Register fields
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regCity, setRegCity] = useState<LocationCity>('Pitești');

  // SMS Verification Step
  const [isVerifyingSms, setIsVerifyingSms] = useState(false);
  const [generatedSmsCode, setGeneratedSmsCode] = useState('');
  const [enteredSmsCode, setEnteredSmsCode] = useState('');
  const [pendingUser, setPendingUser] = useState<User | null>(null);

  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Handle Login
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanInputPhone = cleanPhone(loginPhone);
    if (!cleanInputPhone || cleanInputPhone.length < 8) {
      setErrorMessage('Te rugăm să introduci un număr de telefon valid (ex: 0722 123 456).');
      return;
    }

    // Check if phone is blacklisted by admin
    if (isPhoneBlacklisted(cleanInputPhone)) {
      setErrorMessage('Contul tău a fost blocat de administrator pentru anunțuri false.');
      return;
    }

    if (!loginPassword) {
      setErrorMessage('Te rugăm să introduci parola contului.');
      return;
    }

    const users = getStoredUsers();
    const user = users.find((u) => cleanPhone(u.phone) === cleanInputPhone);

    if (!user) {
      setErrorMessage('Nu există niciun cont cu acest număr de telefon. Apasă pe "Creează cont nou" de mai sus.');
      return;
    }

    if (user.isBlocked) {
      setErrorMessage('Contul tău a fost blocat de administrator pentru anunțuri false.');
      return;
    }

    if (user.password !== loginPassword) {
      setErrorMessage('Parola introdusă este incorectă. Verifică și încearcă din nou.');
      return;
    }

    // Success login
    setCurrentUser(user);
    onLoginSuccess(user);
    onClose();
  };

  // Start Register (trigger mandatory SMS code)
  const handleStartRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!regName.trim() || regName.trim().length < 2) {
      setErrorMessage('Te rugăm să introduci numele tău complet.');
      return;
    }

    const cleanInputPhone = cleanPhone(regPhone);
    if (!cleanInputPhone || cleanInputPhone.length < 9) {
      setErrorMessage('Numărul de telefon este invalid. Introdu cel puțin 10 cifre.');
      return;
    }

    // Check if phone number is blacklisted
    if (isPhoneBlacklisted(cleanInputPhone)) {
      setErrorMessage('Acest număr de telefon este blocat definitiv de administrator pentru tentative de fraudă și nu mai poate fi utilizat.');
      return;
    }

    if (!regPassword || regPassword.length < 4) {
      setErrorMessage('Parola trebuie să aibă minim 4 caractere (ușor de reținut).');
      return;
    }

    // Rule: One phone number = one account
    const users = getStoredUsers();
    const existing = users.find((u) => cleanPhone(u.phone) === cleanInputPhone);
    if (existing) {
      setErrorMessage('Există deja un cont înregistrat cu acest număr de telefon. Te rugăm să intri în cont.');
      return;
    }

    // Generate random 4-digit SMS code
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedSmsCode(code);

    const newUser: User = {
      id: 'user-' + Date.now(),
      name: regName.trim(),
      phone: regPhone.trim(),
      password: regPassword,
      city: regCity,
      createdAt: new Date().toISOString(),
      isBlocked: false,
      isVerifiedSeller: false,
    };

    setPendingUser(newUser);
    setIsVerifyingSms(true);
    setEnteredSmsCode('');
  };

  // Confirm SMS code
  const handleConfirmSms = (e: React.FormEvent) => {
    e.preventDefault();
    if (enteredSmsCode.trim() !== generatedSmsCode) {
      setErrorMessage('Codul SMS introdus este incorect. Verifică mesajul primit.');
      return;
    }

    if (!pendingUser) return;

    // Check again if phone was blacklisted in meantime
    if (isPhoneBlacklisted(pendingUser.phone)) {
      setErrorMessage('Acest număr de telefon este blocat definitiv de administrator.');
      return;
    }

    // Save user
    const users = getStoredUsers();
    const updatedUsers = [...users, pendingUser];
    saveStoredUsers(updatedUsers);

    setCurrentUser(pendingUser);
    onLoginSuccess(pendingUser);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div 
        className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col border border-slate-200 animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-[#002f34] text-white p-5 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-lg bg-[#23e5db] flex items-center justify-center font-black text-[#002f34] text-sm">
                PB
              </span>
              <h3 className="text-xl font-black">
                Pitești<span className="text-[#23e5db]">Bazar</span>
              </h3>
            </div>
            <p className="text-xs text-slate-300 mt-1">
              Comunitate sigură • Verificare obligatorie prin SMS
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-xl transition cursor-pointer"
            title="Închide"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Reason banner if triggered from adding ad */}
        {promptReason && (
          <div className="bg-amber-50 border-b border-amber-200 px-5 py-3 text-amber-900 text-xs sm:text-sm font-semibold flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-700 shrink-0" />
            <span>{promptReason}</span>
          </div>
        )}

        {/* Tab switchers: Intra in cont / Creeaza cont nou */}
        {!isVerifyingSms && (
          <div className="grid grid-cols-2 p-2 bg-slate-100 gap-2 border-b border-slate-200">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setErrorMessage(null);
              }}
              className={`py-3 px-4 rounded-xl font-black text-sm sm:text-base transition cursor-pointer ${
                mode === 'login'
                  ? 'bg-white text-[#002f34] shadow-md border-b-2 border-[#002f34]'
                  : 'text-slate-600 hover:bg-slate-200/60'
              }`}
            >
              Intră în cont
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setErrorMessage(null);
              }}
              className={`py-3 px-4 rounded-xl font-black text-sm sm:text-base transition cursor-pointer ${
                mode === 'register'
                  ? 'bg-white text-[#002f34] shadow-md border-b-2 border-[#002f34]'
                  : 'text-slate-600 hover:bg-slate-200/60'
              }`}
            >
              Creează cont nou
            </button>
          </div>
        )}

        {/* Body content */}
        <div className="p-5 sm:p-6 space-y-4">
          
          {/* Error notice (especially anti-scam block message) */}
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-50 border-2 border-rose-300 text-rose-900 text-sm font-bold flex items-start gap-2.5">
              <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* SMS VERIFICATION STEP */}
          {isVerifyingSms ? (
            <form onSubmit={handleConfirmSms} className="space-y-4">
              <div className="bg-emerald-50 rounded-2xl p-4 border-2 border-emerald-300 space-y-2">
                <div className="flex items-center gap-2 text-emerald-950 font-bold text-sm">
                  <MessageSquare className="w-5 h-5 text-emerald-600 animate-bounce" />
                  <span>Verificare SMS obligatorie pentru siguranță:</span>
                </div>
                <div className="bg-white p-3 rounded-xl border border-emerald-200 shadow-xs">
                  <p className="text-xs text-slate-500 font-medium">SMS primit pe numărul <strong className="text-slate-900">{pendingUser?.phone}</strong>:</p>
                  <p className="text-sm font-semibold text-slate-900 mt-1">
                    Codul tău unic de activare este:{' '}
                    <span className="text-lg font-black text-[#002f34] bg-emerald-100 px-2 py-0.5 rounded tracking-widest">
                      {generatedSmsCode}
                    </span>
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setEnteredSmsCode(generatedSmsCode)}
                  className="text-xs font-bold text-emerald-800 hover:text-emerald-950 underline cursor-pointer"
                >
                  Apasă aici pentru completare automată a codului ({generatedSmsCode})
                </button>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-900 mb-1">
                  Introdu codul primit prin SMS (4 cifre):
                </label>
                <input
                  type="text"
                  maxLength={6}
                  required
                  autoFocus
                  value={enteredSmsCode}
                  onChange={(e) => setEnteredSmsCode(e.target.value)}
                  placeholder="ex: 1234"
                  className="w-full text-center tracking-widest text-2xl font-black px-4 py-3 rounded-xl border-2 border-slate-300 focus:border-[#002f34] focus:ring-2 focus:ring-[#23e5db]/30 outline-none text-slate-900"
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-xl bg-[#002f34] hover:bg-[#001d21] text-white font-black text-base shadow-lg transition active:scale-98 cursor-pointer flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-5 h-5 text-[#23e5db]" />
                <span>Activează contul și intră pe site</span>
              </button>

              <button
                type="button"
                onClick={() => setIsVerifyingSms(false)}
                className="w-full text-xs text-slate-500 hover:text-slate-800 py-1"
              >
                ← Înapoi la modificarea numărului
              </button>
            </form>
          ) : mode === 'login' ? (
            /* LOGIN FORM */
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-slate-900 mb-1">
                  Număr de telefon
                </label>
                <div className="relative">
                  <Phone className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="tel"
                    required
                    value={loginPhone}
                    onChange={(e) => setLoginPhone(e.target.value)}
                    placeholder="ex: 0744 321 890"
                    className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-300 focus:border-[#002f34] focus:ring-2 focus:ring-[#23e5db]/30 text-slate-900 font-bold text-base outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-slate-900 mb-1">
                  Parolă
                </label>
                <div className="relative">
                  <Lock className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="password"
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-300 focus:border-[#002f34] focus:ring-2 focus:ring-[#23e5db]/30 text-slate-900 font-bold text-base outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-xl bg-[#002f34] hover:bg-[#001d21] text-white font-black text-base shadow-xl transition active:scale-98 cursor-pointer flex items-center justify-center gap-2 mt-2"
              >
                <span>Intră în cont</span>
                <ArrowRight className="w-5 h-5 text-[#23e5db]" />
              </button>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs text-slate-600 mt-4 space-y-1">
                <span className="font-bold text-slate-800 block">Conturi de test:</span>
                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setLoginPhone('0744321890');
                      setLoginPassword('ionel123');
                    }}
                    className="bg-white hover:bg-slate-100 px-2 py-1 rounded border border-slate-300 font-medium text-slate-800 cursor-pointer"
                  >
                    Ionel (0744 321 890)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setLoginPhone('0721554321');
                      setLoginPassword('elena123');
                    }}
                    className="bg-white hover:bg-slate-100 px-2 py-1 rounded border border-slate-300 font-medium text-slate-800 cursor-pointer"
                  >
                    Elena (0721 554 321)
                  </button>
                </div>
              </div>
            </form>
          ) : (
            /* REGISTER FORM */
            <form onSubmit={handleStartRegister} className="space-y-3.5">
              <div className="bg-emerald-50/70 p-3 rounded-xl border border-emerald-200 text-xs text-emerald-950 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  <strong>1 număr de telefon = 1 cont sigur.</strong> Verificăm fiecare utilizator prin SMS pentru a preveni hoții și anunțurile false.
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Numele tău complet <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="ex: Marian Niculescu"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 focus:border-[#002f34] text-slate-900 font-medium text-sm outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Număr de telefon real <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                  <input
                    type="tel"
                    required
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder="ex: 0722 123 456"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 focus:border-[#002f34] text-slate-900 font-bold text-sm outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Alege o parolă <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                  <input
                    type="password"
                    required
                    value={regPassword}
                    onChange={(e) => setRegPassword(e.target.value)}
                    placeholder="ex: parola123"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 focus:border-[#002f34] text-slate-900 font-bold text-sm outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-900 mb-1">
                  Orașul tău în Argeș <span className="text-rose-500">*</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {CITIES.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setRegCity(c)}
                      className={`py-2 px-1 text-xs font-bold rounded-lg border text-center transition cursor-pointer ${
                        regCity === c
                          ? 'bg-[#002f34] text-white border-[#002f34]'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#23e5db] to-[#14b8a6] hover:from-[#35eee5] hover:to-[#0d9488] text-[#002f34] font-black text-base shadow-lg transition active:scale-98 cursor-pointer flex items-center justify-center gap-2 mt-2"
              >
                <Sparkles className="w-5 h-5 text-[#002f34]" />
                <span>Verifică numărul prin SMS</span>
              </button>
            </form>
          )}

        </div>

      </div>
    </div>
  );
};
