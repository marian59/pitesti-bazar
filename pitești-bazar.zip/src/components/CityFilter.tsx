import React from 'react';
import { LocationCity, SortOption } from '../types';
import { CITIES, CATEGORIES } from '../data/seedAds';
import { MapPin, SlidersHorizontal, Check } from 'lucide-react';

interface CityFilterProps {
  selectedCity: LocationCity | 'all';
  onCitySelect: (city: LocationCity | 'all') => void;
  selectedCategory: string;
  onCategorySelect: (category: string) => void;
  sortOption: SortOption;
  onSortChange: (sort: SortOption) => void;
  cityCounts: Record<string, number>;
  totalCount: number;
}

export const CityFilter: React.FC<CityFilterProps> = ({
  selectedCity,
  onCitySelect,
  selectedCategory,
  onCategorySelect,
  sortOption,
  onSortChange,
  cityCounts,
  totalCount,
}) => {
  return (
    <div className="bg-white border-b border-slate-200 py-4 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main City Tabs - Big clean buttons */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-[#002f34]" />
              Alege Orașul (Filtru Argeș):
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
            {/* All */}
            <button
              onClick={() => onCitySelect('all')}
              className={`flex items-center justify-between px-4 py-3 rounded-xl border-2 font-bold text-sm sm:text-base transition-all cursor-pointer ${
                selectedCity === 'all'
                  ? 'border-[#002f34] bg-[#002f34] text-white shadow-md'
                  : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50'
              }`}
            >
              <span className="truncate">Toate locațiile</span>
              <span
                className={`text-xs px-2 py-0.5 rounded-full font-bold ml-2 ${
                  selectedCity === 'all'
                    ? 'bg-[#23e5db] text-[#002f34]'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                {totalCount}
              </span>
            </button>

            {/* Pitesti */}
            {CITIES.map((city) => {
              const count = cityCounts[city] || 0;
              const isSelected = selectedCity === city;
              return (
                <button
                  key={city}
                  onClick={() => onCitySelect(city)}
                  className={`flex items-center justify-between px-4 py-3 rounded-xl border-2 font-bold text-sm sm:text-base transition-all cursor-pointer ${
                    isSelected
                      ? 'border-[#002f34] bg-[#002f34] text-white shadow-md'
                      : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <span className="truncate">{city}</span>
                  <span
                    className={`text-xs px-2 py-0.5 rounded-full font-bold ml-2 ${
                      isSelected
                        ? 'bg-[#23e5db] text-[#002f34]'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Categories Bar & Sort Row */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pt-2 border-t border-slate-100">
          
          {/* Category Pills (scrollable horizontally) */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none text-xs sm:text-sm">
            {CATEGORIES.map((cat) => {
              const isSelected = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => onCategorySelect(cat)}
                  className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition cursor-pointer ${
                    isSelected
                      ? 'bg-slate-900 text-white font-bold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>

          {/* Sort selector */}
          <div className="flex items-center justify-end gap-2 shrink-0">
            <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
              <SlidersHorizontal className="w-3.5 h-3.5" />
              Sortează:
            </span>
            <select
              value={sortOption}
              onChange={(e) => onSortChange(e.target.value as SortOption)}
              className="bg-slate-100 text-slate-800 text-xs sm:text-sm font-semibold rounded-lg px-2.5 py-1.5 border border-slate-200 focus:outline-none cursor-pointer"
            >
              <option value="newest">Cele mai recente</option>
              <option value="price_asc">Preț: crescător</option>
              <option value="price_desc">Preț: descrescător</option>
            </select>
          </div>

        </div>

      </div>
    </div>
  );
};
