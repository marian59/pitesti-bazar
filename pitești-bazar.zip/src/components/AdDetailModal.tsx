import React, { useState } from 'react';
import { 
  X, 
  MapPin, 
  Clock, 
  Phone, 
  Heart, 
  Share2, 
  Check, 
  User, 
  MessageCircle, 
  Trash2, 
  AlertCircle,
  Eye,
  ShieldCheck,
  AlertTriangle,
  ShieldAlert
} from 'lucide-react';
import { Ad } from '../types';
import { formatPrice, formatTimeAgo, cleanPhoneForWhatsApp } from '../utils/storage';

interface AdDetailModalProps {
  ad: Ad | null;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onDeleteAd?: (id: string) => void;
  onReportAd: (ad: Ad) => void;
  isSellerVerified?: boolean;
}

export const AdDetailModal: React.FC<AdDetailModalProps> = ({
  ad,
  onClose,
  isFavorite,
  onToggleFavorite,
  onDeleteAd,
  onReportAd,
  isSellerVerified,
}) => {
  if (!ad) return null;

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [copiedPhone, setCopiedPhone] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);

  const images = ad.images && ad.images.length > 0 ? ad.images : [
    'https://images.unsplash.com/photo-1584824486509-112e4181ff6b?w=800&auto=format&fit=crop&q=80'
  ];

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(ad.phone);
    setCopiedPhone(true);
    setTimeout(() => setCopiedPhone(false), 2500);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: ad.title,
        text: `${ad.title} - ${formatPrice(ad.price, ad.currency, ad.isFree)} pe Pitești Bazar`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const waPhone = cleanPhoneForWhatsApp(ad.phone);
  const waMessage = encodeURIComponent(`Bună ziua! Vă contactez în legătură cu anunțul "${ad.title}" de pe Pitești Bazar.`);
  const waUrl = `https://wa.me/${waPhone}?text=${waMessage}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div 
        className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[92vh] border border-slate-200 animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2 text-xs sm:text-sm text-slate-500 font-medium">
            <span className="text-[#002f34] font-bold">Pitești Bazar</span>
            <span>&gt;</span>
            <span>{ad.category}</span>
            <span>&gt;</span>
            <span className="font-semibold text-slate-800">{ad.city}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleShare}
              className="p-2 text-slate-500 hover:text-slate-800 hover:bg-slate-200 rounded-lg transition cursor-pointer"
              title="Distribuie anunțul"
            >
              {copiedLink ? <Check className="w-5 h-5 text-emerald-600" /> : <Share2 className="w-5 h-5" />}
            </button>
            <button
              onClick={() => onToggleFavorite(ad.id)}
              className="p-2 text-slate-500 hover:text-rose-500 hover:bg-slate-200 rounded-lg transition cursor-pointer"
              title={isFavorite ? 'Elimină din favorite' : 'Salvează la favorite'}
            >
              <Heart className={`w-5 h-5 ${isFavorite ? 'fill-rose-500 text-rose-500' : ''}`} />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg transition ml-1 cursor-pointer"
              title="Închide"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Modal Body (Scrollable) */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* Main Grid: Gallery + Quick Summary */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Gallery Column (7 cols) */}
            <div className="lg:col-span-7 flex flex-col gap-3">
              <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-slate-100 border border-slate-200">
                <img
                  src={images[activeImageIndex] || images[0]}
                  alt={ad.title}
                  className="w-full h-full object-cover"
                />
                {ad.isUserCreated && (
                  <span className="absolute top-3 left-3 bg-[#23e5db] text-[#002f34] text-xs font-black uppercase px-2.5 py-1 rounded shadow">
                    Adăugat de tine
                  </span>
                )}
                {ad.status === 'pending' && (
                  <span className="absolute top-3 right-3 bg-amber-500 text-slate-950 text-xs font-black uppercase px-2.5 py-1 rounded shadow">
                    În așteptare aprobare
                  </span>
                )}
              </div>

              {/* Thumbnails if multiple images */}
              {images.length > 1 && (
                <div className="flex gap-2 overflow-x-auto pb-1">
                  {images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImageIndex(idx)}
                      className={`relative w-20 h-16 rounded-lg overflow-hidden border-2 transition shrink-0 ${
                        activeImageIndex === idx ? 'border-[#002f34] ring-2 ring-[#23e5db]' : 'border-slate-200 opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              {/* Red Scam Report Button - Clear & Visible as requested */}
              <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0" />
                  <span className="text-xs text-rose-950 font-medium">
                    Ți se pare ceva suspect la acest anunț?
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => onReportAd(ad)}
                  className="px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-xl shadow-xs transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap active:scale-95"
                >
                  <AlertTriangle className="w-4 h-4 text-yellow-300" />
                  <span>⚠️ Raportează anunț fals / Țeapă</span>
                </button>
              </div>
            </div>

            {/* Price & Contact Column (5 cols) */}
            <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
              
              {/* Header Box */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <Clock className="w-4 h-4 text-slate-400" />
                  <span>Publicat {formatTimeAgo(ad.createdAt)}</span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Eye className="w-3.5 h-3.5" />
                    {(ad.viewsCount || 1) + 1} vizualizări
                  </span>
                </div>

                <h1 className="text-xl sm:text-2xl font-bold text-slate-900 leading-snug">
                  {ad.title}
                </h1>

                {/* Big Price Box */}
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex items-baseline justify-between">
                  <div>
                    <span className="text-2xl sm:text-3xl font-black text-[#002f34]">
                      {formatPrice(ad.price, ad.currency, ad.isFree)}
                    </span>
                    {ad.isNegotiable && !ad.isFree && (
                      <span className="block text-xs font-bold text-slate-500 mt-0.5">
                        Preț negociabil
                      </span>
                    )}
                  </div>
                  <span className="text-xs bg-[#23e5db]/20 text-[#002f34] font-bold px-2 py-1 rounded">
                    {ad.category}
                  </span>
                </div>

                {/* Location indicator */}
                <div className="flex items-center gap-2 p-3 bg-emerald-50 text-emerald-950 rounded-xl border border-emerald-200 text-sm">
                  <MapPin className="w-5 h-5 text-emerald-700 shrink-0" />
                  <div>
                    <div className="font-bold">{ad.city}{ad.neighborhood ? `, ${ad.neighborhood}` : ''}</div>
                    <div className="text-xs text-emerald-800">Județul Argeș, România</div>
                  </div>
                </div>
              </div>

              {/* Seller Contact Card with Verified Seller Badge */}
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3 mt-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-[#002f34] text-white flex items-center justify-center font-bold text-lg">
                      {ad.sellerName.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="font-bold text-slate-900">{ad.sellerName}</div>
                      
                      {/* Badge "Vanzator verificat" */}
                      {isSellerVerified ? (
                        <div className="text-xs font-bold text-emerald-700 flex items-center gap-1 bg-emerald-100/70 px-2 py-0.5 rounded border border-emerald-200 mt-0.5">
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                          <span>✓ Verificat de Pitești Bazar</span>
                        </div>
                      ) : (
                        <div className="text-xs text-slate-500 flex items-center gap-1">
                          <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
                          <span>Cont verificat prin SMS</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Direct Call Button */}
                <a
                  href={`tel:${ad.phone}`}
                  className="w-full flex items-center justify-center gap-2 bg-[#002f34] hover:bg-[#001d21] text-white font-bold py-3.5 px-4 rounded-xl shadow-md active:scale-98 transition text-center cursor-pointer text-base"
                >
                  <Phone className="w-5 h-5 text-[#23e5db]" />
                  <span>Sună vânzătorul: {ad.phone}</span>
                </a>

                {/* WhatsApp Button */}
                <a
                  href={waUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#20ba5a] text-white font-bold py-3 px-4 rounded-xl shadow-sm active:scale-98 transition text-center cursor-pointer text-sm"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>Trimite mesaj pe WhatsApp</span>
                </a>

                {/* Copy phone button */}
                <button
                  type="button"
                  onClick={handleCopyPhone}
                  className="w-full text-xs text-slate-600 hover:text-slate-900 font-semibold py-1 rounded transition text-center cursor-pointer"
                >
                  {copiedPhone ? '✓ Număr copiat în clipboard!' : 'Copiază numărul de telefon'}
                </button>
              </div>

            </div>

          </div>

          {/* Description Section */}
          <div className="border-t border-slate-200 pt-5 space-y-3">
            <h2 className="text-lg font-bold text-slate-900">Descriere anunț</h2>
            <div className="bg-slate-50/70 p-4 rounded-xl border border-slate-200 text-slate-700 leading-relaxed whitespace-pre-line text-sm sm:text-base">
              {ad.description}
            </div>
          </div>

          {/* Safety Warning Advice */}
          <div className="p-4 bg-amber-50/70 rounded-xl border border-amber-200/80 text-amber-950 text-xs sm:text-sm space-y-1">
            <div className="font-bold flex items-center gap-1.5 text-amber-900">
              <ShieldCheck className="w-4 h-4 text-amber-700" />
              <span>Ghid de siguranță Pitești Bazar:</span>
            </div>
            <p className="text-xs text-amber-900/90 leading-relaxed">
              • Nu trimite niciodată bani în avans pe card sau prin transfer bancar!<br/>
              • Întâlnește-te personal cu vânzătorul în locuri publice din Pitești, Mioveni sau Curtea de Argeș pentru a testa produsul înainte de plată.<br/>
              • Raportează imediat orice comportament suspect folosind butonul roșu de mai sus.
            </p>
          </div>

          {/* Delete action if user created or owner */}
          {onDeleteAd && (
            <div className="border-t border-slate-200 pt-4 flex items-center justify-between">
              <div className="text-xs text-slate-400">
                ID Anunț: <span className="font-mono">{ad.id}</span>
              </div>
              
              {!showConfirmDelete ? (
                <button
                  type="button"
                  onClick={() => setShowConfirmDelete(true)}
                  className="text-xs text-rose-600 hover:text-rose-800 font-bold flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-rose-50 transition cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  Șterge acest anunț
                </button>
              ) : (
                <div className="flex items-center gap-2 bg-rose-50 p-2 rounded-lg border border-rose-200">
                  <span className="text-xs text-rose-700 font-semibold">Sigur dorești să ștergi?</span>
                  <button
                    onClick={() => {
                      onDeleteAd(ad.id);
                      onClose();
                    }}
                    className="text-xs bg-rose-600 hover:bg-rose-700 text-white font-bold px-3 py-1 rounded transition"
                  >
                    Da, șterge
                  </button>
                  <button
                    onClick={() => setShowConfirmDelete(false)}
                    className="text-xs text-slate-600 hover:text-slate-800 px-2 py-1"
                  >
                    Anulează
                  </button>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Modal Bottom Footer */}
        <div className="px-6 py-3 bg-slate-100 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Pitești Bazar - Cumpără și vinde în siguranță în Argeș
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs sm:text-sm font-bold rounded-lg transition cursor-pointer"
          >
            Închide
          </button>
        </div>

      </div>
    </div>
  );
};
