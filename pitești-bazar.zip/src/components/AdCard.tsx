import React from 'react';
import { Heart, MapPin, Clock, Sparkles, ShieldCheck, AlertTriangle } from 'lucide-react';
import { Ad } from '../types';
import { formatPrice, formatTimeAgo } from '../utils/storage';

interface AdCardProps {
  ad: Ad;
  isFavorite: boolean;
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  onSelect: (ad: Ad) => void;
  onReportAd?: (ad: Ad, e: React.MouseEvent) => void;
  isSellerVerified?: boolean;
}

export const AdCard: React.FC<AdCardProps> = ({
  ad,
  isFavorite,
  onToggleFavorite,
  onSelect,
  onReportAd,
  isSellerVerified,
}) => {
  const mainImage = ad.images && ad.images.length > 0 
    ? ad.images[0] 
    : 'https://images.unsplash.com/photo-1584824486509-112e4181ff6b?w=800&auto=format&fit=crop&q=80';

  return (
    <div
      onClick={() => onSelect(ad)}
      className={`group bg-white rounded-xl border transition-all flex flex-col overflow-hidden cursor-pointer relative ${
        ad.isPromoted
          ? 'border-amber-400 shadow-md ring-1 ring-amber-400/50 hover:shadow-lg'
          : 'border-slate-200 hover:border-slate-300 shadow-xs hover:shadow-md'
      }`}
    >
      {/* Promoted highlight ribbon on card top if promoted */}
      {ad.isPromoted && (
        <div className="bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-[10px] tracking-wider uppercase px-3 py-1 flex items-center justify-between">
          <span className="flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-slate-950 fill-current" />
            Anunț Promovat
          </span>
          <span className="text-[9px] font-bold opacity-80">Recomandat</span>
        </div>
      )}

      {/* Image container */}
      <div className="relative aspect-[4/3] bg-slate-100 overflow-hidden">
        <img
          src={mainImage}
          alt={ad.title}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          onError={(e) => {
            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1584824486509-112e4181ff6b?w=800&auto=format&fit=crop&q=80';
          }}
        />

        {/* Badges on image */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 z-10">
          {ad.isUserCreated && (
            <span className="bg-[#23e5db] text-[#002f34] text-[11px] font-black uppercase px-2 py-0.5 rounded shadow-sm">
              Anunțul Tău
            </span>
          )}
          {ad.status === 'pending' && (
            <span className="bg-amber-500 text-slate-950 text-[10px] font-black uppercase px-2 py-0.5 rounded shadow-sm">
              În așteptare
            </span>
          )}
        </div>

        {/* Favorite heart button */}
        <button
          type="button"
          onClick={(e) => onToggleFavorite(ad.id, e)}
          className="absolute top-2.5 right-2.5 p-2 rounded-full bg-white/90 hover:bg-white text-slate-700 hover:text-rose-500 shadow-md backdrop-blur-sm transition-all z-10 cursor-pointer"
          title={isFavorite ? 'Elimină din favorite' : 'Salvează la favorite'}
        >
          <Heart
            className={`w-5 h-5 transition-colors ${
              isFavorite ? 'fill-rose-500 text-rose-500' : 'text-slate-600'
            }`}
          />
        </button>

        {/* Category tag */}
        <div className="absolute bottom-2 left-2 z-10">
          <span className="bg-black/60 backdrop-blur-md text-white text-[11px] font-medium px-2 py-0.5 rounded">
            {ad.category}
          </span>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-3.5 sm:p-4 flex flex-col flex-1 justify-between">
        <div>
          {/* Title */}
          <h3 className="font-semibold text-slate-900 text-sm sm:text-base line-clamp-2 leading-snug group-hover:text-teal-700 transition-colors mb-1.5">
            {ad.title}
          </h3>

          {/* Price */}
          <div className="flex items-baseline gap-2 mb-2">
            <span className="text-lg sm:text-xl font-black text-[#002f34]">
              {formatPrice(ad.price, ad.currency, ad.isFree)}
            </span>
            {ad.isNegotiable && !ad.isFree && (
              <span className="text-xs text-slate-500 font-medium bg-slate-100 px-1.5 py-0.5 rounded">
                Negociabil
              </span>
            )}
          </div>

          {/* Seller Verified Badge */}
          <div className="flex items-center gap-1 text-[11px] font-bold mb-2">
            {isSellerVerified ? (
              <span className="inline-flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Verificat de Pitești Bazar</span>
              </span>
            ) : (
              <span className="text-slate-500 text-[11px]">
                Vânzător: {ad.sellerName}
              </span>
            )}
          </div>
        </div>

        {/* Card Footer: Location & Date */}
        <div>
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <div className="flex items-center gap-1 font-medium truncate mr-2">
              <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span className="truncate">
                {ad.city}
                {ad.neighborhood ? `, ${ad.neighborhood}` : ''}
              </span>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-slate-400 shrink-0">
              <Clock className="w-3 h-3" />
              <span>{formatTimeAgo(ad.createdAt)}</span>
            </div>
          </div>

          {/* Red Scam Report Button right on card */}
          {onReportAd && (
            <div className="mt-2 pt-2 border-t border-slate-100 flex justify-end">
              <button
                type="button"
                onClick={(e) => onReportAd(ad, e)}
                className="text-[11px] font-bold text-rose-600 hover:text-rose-800 hover:bg-rose-50 px-2 py-1 rounded transition flex items-center gap-1 cursor-pointer"
                title="Raportează acest anunț ca fiind fals sau suspect"
              >
                <AlertTriangle className="w-3 h-3 text-rose-500" />
                <span>Raportează țeapă</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
