import React, { useState } from 'react';
import { X, AlertTriangle, ShieldCheck, CheckCircle2, Send } from 'lucide-react';
import { Ad, AdReport } from '../types';

interface ReportModalProps {
  ad: Ad | null;
  isOpen: boolean;
  onClose: () => void;
  onSubmitReport: (report: AdReport) => void;
}

const REPORT_REASONS = [
  'Cere bani în avans pe card sau cont bancar',
  'Preț nerealist / suspect de mic pentru acest produs',
  'Produsul nu există sau pozele sunt copiate de pe internet',
  'Trimite linkuri suspecte pe WhatsApp / Tentativă de fraudă',
  'Număr de telefon fals sau vânzător agresiv',
  'Alt motiv',
];

export const ReportModal: React.FC<ReportModalProps> = ({
  ad,
  isOpen,
  onClose,
  onSubmitReport,
}) => {
  if (!isOpen || !ad) return null;

  const [selectedReason, setSelectedReason] = useState(REPORT_REASONS[0]);
  const [details, setDetails] = useState('');
  const [reporterPhone, setReporterPhone] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const report: AdReport = {
      id: 'rep-' + Date.now(),
      adId: ad.id,
      adTitle: ad.title,
      sellerName: ad.sellerName,
      sellerPhone: ad.phone,
      reason: selectedReason,
      details: details.trim() || undefined,
      reporterPhone: reporterPhone.trim() || undefined,
      createdAt: new Date().toISOString(),
      isResolved: false,
    };

    onSubmitReport(report);
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      onClose();
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div 
        className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col border-2 border-rose-500 animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-rose-600 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-white">
              <AlertTriangle className="w-5 h-5 text-yellow-300" />
            </div>
            <div>
              <h3 className="text-lg font-black tracking-tight">
                Raportează Anunț Fals / Țeapă
              </h3>
              <p className="text-xs text-rose-100">
                Sesizarea ta ajunge direct la administratorul din Pitești
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {isSubmitted ? (
          <div className="p-8 text-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h4 className="text-xl font-black text-slate-900">
              Raportul a fost transmis cu succes!
            </h4>
            <p className="text-sm text-slate-600 max-w-sm mx-auto">
              Administratorul Pitești Bazar a primit sesizarea și verifică anunțul în cel mult 10 minute. Îți mulțumim pentru că ajuți la protejarea comunității!
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4">
            
            {/* Ad summary box */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
              <span className="text-slate-500 block">Anunțul raportat:</span>
              <span className="font-bold text-slate-900 block truncate text-sm mt-0.5">
                {ad.title}
              </span>
              <span className="text-slate-600 block mt-0.5">
                Vânzător: <strong>{ad.sellerName}</strong> • Tel: {ad.phone}
              </span>
            </div>

            {/* Choose reason */}
            <div>
              <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                Alege motivul raportării:
              </label>
              <div className="space-y-1.5">
                {REPORT_REASONS.map((reason) => (
                  <label
                    key={reason}
                    className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs sm:text-sm font-medium transition cursor-pointer ${
                      selectedReason === reason
                        ? 'border-rose-500 bg-rose-50/60 text-rose-950 font-bold'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <input
                      type="radio"
                      name="reportReason"
                      checked={selectedReason === reason}
                      onChange={() => setSelectedReason(reason)}
                      className="w-4 h-4 text-rose-600 focus:ring-rose-500 cursor-pointer"
                    />
                    <span>{reason}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Details */}
            <div>
              <label className="block text-xs font-bold text-slate-900 mb-1">
                Detalii suplimentare (opțional):
              </label>
              <textarea
                rows={3}
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                placeholder="Explică pe scurt ce ai observat suspect..."
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs sm:text-sm outline-none focus:border-rose-500"
              />
            </div>

            {/* Reporter phone */}
            <div>
              <label className="block text-xs font-bold text-slate-900 mb-1">
                Telefonul tău (opțional):
              </label>
              <input
                type="tel"
                value={reporterPhone}
                onChange={(e) => setReporterPhone(e.target.value)}
                placeholder="ex: 0722 000 000 (în caz că adminul are întrebări)"
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs sm:text-sm outline-none focus:border-rose-500"
              />
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-black text-sm sm:text-base shadow-lg transition active:scale-98 cursor-pointer flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                <span>Trimite Raportul către Administrator</span>
              </button>
              <p className="text-[11px] text-center text-slate-400 mt-2">
                Administratorul suprem verifică sesizările non-stop pentru siguranța vizitatorilor.
              </p>
            </div>

          </form>
        )}

      </div>
    </div>
  );
};
