import React from 'react';
import { MapPin, ShieldAlert, RefreshCw, Lock } from 'lucide-react';
import { LocationCity } from '../types';
import { CITIES } from '../data/seedAds';

interface FooterProps {
  onSelectCity: (city: LocationCity | 'all') => void;
  onResetData: () => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectCity, onResetData, onOpenAdmin }) => {
  return (
    <footer className="bg-[#002f34] text-white mt-16 border-t border-[#002327]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 pb-8 border-b border-white/10">
          
          {/* Brand & info */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg bg-[#23e5db] flex items-center justify-center font-black text-[#002f34]">
                PB
              </div>
              <span className="text-xl font-black text-white">
                Pitești<span className="text-[#23e5db]">Bazar</span>
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Platforma profesională de anunțuri gratuite dedicată exclusiv județului Argeș. Autentificare simplă cu număr de telefon, vânzări rapide și acces direct pentru vizitatori.
            </p>
          </div>

          {/* Quick city locations */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-[#23e5db]" />
              Zone acoperite în Argeș:
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-300">
              {CITIES.map((city) => (
                <li key={city}>
                  <button
                    onClick={() => onSelectCity(city)}
                    className="hover:text-[#23e5db] transition cursor-pointer flex items-center gap-1"
                  >
                    <span>•</span>
                    <span className="font-semibold">{city}</span>
                    <span className="text-slate-400">- toate cartierele</span>
                  </button>
                </li>
              ))}
              <li>
                <button
                  onClick={() => onSelectCity('all')}
                  className="hover:text-[#23e5db] transition cursor-pointer flex items-center gap-1 text-[#23e5db]"
                >
                  <span>•</span>
                  <span>Toate anunțurile din Argeș</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Admin access & reset data */}
          <div className="flex flex-col justify-between space-y-3">
            <div>
              <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-amber-400" />
                Acces Administrator:
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed mb-3">
                Panou de administrare suprem cu gestionare utilizatori, parole, aprobare/promovare anunțuri și statistici în timp real.
              </p>
              <button
                onClick={onOpenAdmin}
                className="inline-flex items-center gap-2 bg-[#001d21] hover:bg-[#001417] text-amber-300 px-3.5 py-2 rounded-xl text-xs font-bold border border-amber-400/40 transition cursor-pointer"
              >
                <span>👑</span>
                <span>Panou Administrator Suprem (/admin)</span>
              </button>
            </div>

            <button
              onClick={onResetData}
              className="text-xs text-slate-400 hover:text-white flex items-center gap-1.5 self-start py-1 transition cursor-pointer"
              title="Resetează lista la datele implicite"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reîncarcă anunțurile implicite</span>
            </button>
          </div>

        </div>

        {/* Bottom copyright */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-2">
          <div>
            © {new Date().getFullYear()} Pitești Bazar • Creat ca pe OLX pentru Pitești, Mioveni și Curtea de Argeș.
          </div>
          <div className="flex items-center gap-2 text-slate-400">
            <span>Ușor de folosit • Butoane mari • Fără email complicat</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
