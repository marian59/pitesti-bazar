import React from 'react';
import { PlusCircle, Heart, Tag, User as UserIcon, ShieldAlert, LogIn } from 'lucide-react';
import { User, LocationCity } from '../types';

interface NavbarProps {
  currentUser: User | null;
  onOpenAddModal: () => void;
  onOpenAuthModal: (mode?: 'login' | 'register') => void;
  onOpenMyAccount: () => void;
  onOpenAdmin: () => void;
  isAdminLoggedIn: boolean;
  favoritesCount: number;
  onShowFavorites: () => void;
  isShowingFavorites: boolean;
  onResetFilters: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  onOpenAddModal,
  onOpenAuthModal,
  onOpenMyAccount,
  onOpenAdmin,
  isAdminLoggedIn,
  favoritesCount,
  onShowFavorites,
  isShowingFavorites,
  onResetFilters,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-[#002f34] text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Slogan */}
          <div 
            onClick={onResetFilters}
            className="flex items-center gap-3 cursor-pointer select-none group"
          >
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#23e5db] to-[#00a396] flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
              <span className="text-2xl font-black text-[#002f34] tracking-tighter">PB</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-black tracking-tight text-white group-hover:text-[#23e5db] transition-colors">
                  Pitești<span className="text-[#23e5db]">Bazar</span>
                </span>
                <span className="hidden md:inline-block text-[11px] font-bold uppercase tracking-wider bg-[#001d21] text-[#23e5db] px-2 py-0.5 rounded border border-[#23e5db]/30">
                  Argeș
                </span>
              </div>
              <p className="text-xs text-slate-300 font-medium hidden sm:block">
                Anunțuri Pitești • Mioveni • Curtea de Argeș
              </p>
            </div>
          </div>

          {/* Right Action buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            
            {/* Admin shortcut button */}
            <button
              onClick={onOpenAdmin}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 sm:px-3 sm:py-2 rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                isAdminLoggedIn
                  ? 'bg-amber-400 text-slate-950 shadow-md ring-2 ring-amber-300'
                  : 'bg-[#002226] text-amber-300 hover:bg-[#001719]'
              }`}
              title="Panou Administrator Suprem (/admin)"
            >
              <span>👑</span>
              <span className="hidden lg:inline">Admin</span>
            </button>

            {/* Favorites button */}
            <button
              onClick={onShowFavorites}
              className={`flex items-center gap-1.5 px-2.5 py-2 sm:px-3 sm:py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                isShowingFavorites
                  ? 'bg-rose-500 text-white shadow'
                  : 'bg-[#002428] text-slate-200 hover:text-white hover:bg-[#001b1e]'
              }`}
              title="Anunțuri favorite"
            >
              <Heart className={`w-4 h-4 sm:w-5 sm:h-5 ${isShowingFavorites ? 'fill-current' : ''}`} />
              <span className="hidden md:inline">Favorite</span>
              {favoritesCount > 0 && (
                <span className="px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-rose-500 text-white">
                  {favoritesCount}
                </span>
              )}
            </button>

            {/* User Account / Login State */}
            {currentUser ? (
              <button
                onClick={onOpenMyAccount}
                className="flex items-center gap-2 bg-[#002428] hover:bg-[#001b1e] text-white px-3 py-2 sm:px-3.5 sm:py-2.5 rounded-xl border border-[#23e5db]/30 text-xs sm:text-sm font-bold transition cursor-pointer"
                title="Deschide Contul meu & Anunțurile mele"
              >
                <div className="w-6 h-6 rounded-full bg-[#23e5db] text-[#002f34] flex items-center justify-center font-black text-xs">
                  {currentUser.name.charAt(0).toUpperCase()}
                </div>
                <span className="hidden sm:inline max-w-[110px] truncate">{currentUser.name}</span>
                <span className="text-[11px] text-[#23e5db] hidden md:inline">Contul meu</span>
              </button>
            ) : (
              <div className="flex items-center gap-1 sm:gap-2">
                <button
                  onClick={() => onOpenAuthModal('login')}
                  className="bg-[#002428] hover:bg-[#001b1e] text-slate-100 hover:text-white px-3 py-2 sm:px-3.5 sm:py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer flex items-center gap-1.5"
                >
                  <LogIn className="w-4 h-4 text-[#23e5db]" />
                  <span>Intră în cont</span>
                </button>
              </div>
            )}

            {/* Big Green/Teal "Adaugă anunț gratis" Button */}
            <button
              onClick={onOpenAddModal}
              className="flex items-center gap-2 bg-gradient-to-r from-[#22c55e] to-[#16a34a] hover:from-[#2ecc71] hover:to-[#1ebb5b] text-white font-black px-3.5 sm:px-5 py-2.5 sm:py-3 rounded-xl shadow-lg hover:shadow-emerald-500/20 active:scale-95 transition-all text-xs sm:text-base cursor-pointer border border-emerald-400/40"
            >
              <PlusCircle className="w-4 h-4 sm:w-5 sm:h-5 stroke-[2.5]" />
              <span className="tracking-tight whitespace-nowrap">Adaugă anunț gratis</span>
            </button>

          </div>

        </div>
      </div>
    </header>
  );
};
