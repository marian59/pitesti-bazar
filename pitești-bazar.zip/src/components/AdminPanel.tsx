import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Users, 
  Package, 
  DollarSign, 
  Eye, 
  Trash2, 
  Sparkles, 
  Lock, 
  Mail, 
  Phone, 
  CheckCircle, 
  X, 
  AlertTriangle,
  Settings,
  Search,
  ExternalLink,
  Ban,
  UserCheck,
  RefreshCw,
  Clock,
  ShieldCheck,
  CheckCircle2,
  AlertOctagon,
  FileText
} from 'lucide-react';
import { User, Ad, AdminConfig, DailyStats, AdReport, BlacklistedPhone } from '../types';
import { formatPrice, formatTimeAgo, cleanPhone } from '../utils/storage';

interface AdminPanelProps {
  adminConfig: AdminConfig;
  onUpdateAdminConfig: (cfg: AdminConfig) => void;
  isAdminLoggedIn: boolean;
  onAdminLogin: () => void;
  onAdminLogout: () => void;
  users: User[];
  onUpdateUsers: (users: User[]) => void;
  ads: Ad[];
  onUpdateAds: (ads: Ad[]) => void;
  reports: AdReport[];
  onUpdateReports: (reports: AdReport[]) => void;
  blacklistedPhones: BlacklistedPhone[];
  onUpdateBlacklist: (list: BlacklistedPhone[]) => void;
  dailyStats: DailyStats;
  onClose: () => void;
  onResetAllData: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  adminConfig,
  onUpdateAdminConfig,
  isAdminLoggedIn,
  onAdminLogin,
  onAdminLogout,
  users,
  onUpdateUsers,
  ads,
  onUpdateAds,
  reports,
  onUpdateReports,
  blacklistedPhones,
  onUpdateBlacklist,
  dailyStats,
  onClose,
  onResetAllData,
}) => {
  // First time configuration state
  const [setupEmail, setSetupEmail] = useState(adminConfig.email || 'MarianNiculescu59@gmail.com');
  const [setupPhone, setSetupPhone] = useState(adminConfig.phone || '0722123456');
  const [setupPassword, setSetupPassword] = useState('');
  const [setupPromoPrice, setSetupPromoPrice] = useState(adminConfig.promoPrice || 5);

  // Login state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [failedAttempts, setFailedAttempts] = useState(0);
  const [lockoutTime, setLockoutTime] = useState<number | null>(null);

  // Dashboard active tab
  const [activeTab, setActiveTab] = useState<'reports' | 'pending' | 'ads' | 'users' | 'blacklist' | 'settings'>('reports');
  const [adsSearchQuery, setAdsSearchQuery] = useState('');
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [actionSuccessNotice, setActionSuccessNotice] = useState<string | null>(null);

  const showNotice = (msg: string) => {
    setActionSuccessNotice(msg);
    setTimeout(() => setActionSuccessNotice(null), 3500);
  };

  // Password strength helper
  const getPasswordStrength = (pass: string) => {
    if (!pass) return { score: 0, text: 'Lipsă', color: 'text-slate-400' };
    if (pass.length < 8) return { score: 1, text: 'Prea scurtă (minim 8 caractere)', color: 'text-rose-500' };
    const hasNum = /\d/.test(pass);
    const hasLetter = /[a-zA-Z]/.test(pass);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(pass);

    if (hasNum && hasLetter && hasSpecial) return { score: 3, text: 'Foarte puternică (sigură)', color: 'text-emerald-500' };
    if (hasNum && hasLetter) return { score: 2, text: 'Medie (acceptabilă)', color: 'text-amber-500' };
    return { score: 1, text: 'Slabă (adaugă cifre și litere)', color: 'text-rose-400' };
  };

  // Setup handler with strict 8+ chars and complexity check
  const handleCompleteSetup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!setupPassword || setupPassword.length < 8) {
      alert('Securitate Admin: Parola trebuie să aibă cel puțin 8 caractere pentru a proteja panoul.');
      return;
    }
    const hasNum = /\d/.test(setupPassword);
    const hasLetter = /[a-zA-Z]/.test(setupPassword);
    if (!hasNum || !hasLetter) {
      alert('Securitate Admin: Parola trebuie să conțină atât litere, cât și cifre.');
      return;
    }

    const updatedConfig: AdminConfig = {
      isConfigured: true,
      email: setupEmail.trim(),
      phone: setupPhone.trim(),
      password: setupPassword,
      promoPrice: Number(setupPromoPrice) || 5,
      totalRevenue: adminConfig.totalRevenue || 25,
    };

    onUpdateAdminConfig(updatedConfig);
    onAdminLogin();
  };

  // Login handler with brute force lockout protection
  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    // Check if locked out
    if (lockoutTime && Date.now() < lockoutTime) {
      const remainingSec = Math.ceil((lockoutTime - Date.now()) / 1000);
      setLoginError(`Panou blocat temporar pentru protecție anti-atac. Reîncearcă în ${remainingSec} secunde.`);
      return;
    }

    if (
      loginEmail.trim().toLowerCase() === adminConfig.email.trim().toLowerCase() &&
      loginPassword === adminConfig.password
    ) {
      setFailedAttempts(0);
      setLockoutTime(null);
      onAdminLogin();
    } else {
      const nextFailed = failedAttempts + 1;
      setFailedAttempts(nextFailed);
      if (nextFailed >= 5) {
        setLockoutTime(Date.now() + 60 * 1000); // 1 minute lockout
        setLoginError('Ai greșit parola de 5 ori! Panoul a fost blocat timp de 1 minut pentru securitate.');
      } else {
        setLoginError(`Date de administrator incorecte. Încercări rămase: ${5 - nextFailed}`);
      }
    }
  };

  // ANTI-SCAM ACTION: BLOCK DEFINITIVELY
  const handleBlockDefinitively = (phoneToBlock: string, userName?: string, reportId?: string) => {
    const clean = cleanPhone(phoneToBlock);
    if (!window.confirm(`Ești sigur că vrei să BLOCHEZI DEFINITIV numărul ${phoneToBlock} și utilizatorul asociat? Acesta nu va mai putea intra pe site sau crea cont niciodată!`)) {
      return;
    }

    // 1. Add to blacklist
    const isAlreadyBlacklisted = blacklistedPhones.some((b) => cleanPhone(b.phone) === clean);
    let updatedBlacklist = [...blacklistedPhones];
    if (!isAlreadyBlacklisted) {
      updatedBlacklist = [
        {
          phone: phoneToBlock,
          name: userName || 'Utilizator raportat ca hoț',
          reason: 'Blocat definitiv de administrator pentru anunțuri false / tentativă de țeapă',
          blockedAt: new Date().toISOString(),
        },
        ...blacklistedPhones,
      ];
      onUpdateBlacklist(updatedBlacklist);
    }

    // 2. Mark user as blocked
    const updatedUsers = users.map((u) => {
      if (cleanPhone(u.phone) === clean) {
        return {
          ...u,
          isBlocked: true,
          blockReason: 'Cont blocat de administrator pentru anunțuri false.',
        };
      }
      return u;
    });
    onUpdateUsers(updatedUsers);

    // 3. Mark report as resolved if clicked from reports
    if (reportId) {
      const updatedReports = reports.map((r) => (r.id === reportId ? { ...r, isResolved: true } : r));
      onUpdateReports(updatedReports);
    }

    showNotice(`Numărul ${phoneToBlock} a fost BLOCAT DEFINITIV și trecut pe Lista Neagră!`);
  };

  // ANTI-SCAM ACTION: DELETE ALL ADS OF SCAMMER
  const handleDeleteAllAdsOfUser = (phoneToDelete: string) => {
    const clean = cleanPhone(phoneToDelete);
    const count = ads.filter((a) => cleanPhone(a.phone) === clean).length;

    if (!window.confirm(`Ștergi toate cele ${count} anunțuri ale utilizatorului cu numărul ${phoneToDelete}?`)) {
      return;
    }

    const updatedAds = ads.filter((a) => cleanPhone(a.phone) !== clean);
    onUpdateAds(updatedAds);
    showNotice(`Toate cele ${count} anunțuri ale acestui utilizator au fost șterse definitiv!`);
  };

  // APPROVE PENDING AD
  const handleApproveAd = (adId: string) => {
    const updatedAds = ads.map((a) => (a.id === adId ? { ...a, status: 'approved' as const } : a));
    onUpdateAds(updatedAds);
    showNotice('Anunțul a fost aprobat și este acum vizibil pe site pentru toți vizitatorii!');
  };

  // REJECT / DELETE AD
  const handleRejectAd = (adId: string) => {
    if (window.confirm('Respingi și ștergi acest anunț?')) {
      const updatedAds = ads.filter((a) => a.id !== adId);
      onUpdateAds(updatedAds);
      showNotice('Anunțul a fost respins și șters.');
    }
  };

  // Toggle Promote on an Ad
  const handleTogglePromote = (adId: string) => {
    const updated = ads.map((a) => {
      if (a.id === adId) {
        return { ...a, isPromoted: !a.isPromoted };
      }
      return a;
    });
    onUpdateAds(updated);
    showNotice('Starea de promovare a fost actualizată!');
  };

  // Mark Report as Resolved / False alarm
  const handleResolveReport = (reportId: string) => {
    const updatedReports = reports.map((r) => (r.id === reportId ? { ...r, isResolved: true } : r));
    onUpdateReports(updatedReports);
    showNotice('Raportul a fost marcat ca rezolvat.');
  };

  // Unblock from blacklist
  const handleUnblacklist = (phone: string) => {
    const clean = cleanPhone(phone);
    const updatedBlacklist = blacklistedPhones.filter((b) => cleanPhone(b.phone) !== clean);
    onUpdateBlacklist(updatedBlacklist);

    const updatedUsers = users.map((u) => {
      if (cleanPhone(u.phone) === clean) {
        return { ...u, isBlocked: false };
      }
      return u;
    });
    onUpdateUsers(updatedUsers);
    showNotice(`Numărul ${phone} a fost deblocat din Lista Neagră.`);
  };

  // Save Promo Price
  const handleSavePromoPrice = (newPrice: number) => {
    const updated: AdminConfig = {
      ...adminConfig,
      promoPrice: newPrice,
    };
    onUpdateAdminConfig(updated);
    showNotice(`Prețul de promovare a fost setat la ${newPrice} lei!`);
  };

  // First time setup prompt
  if (!adminConfig.isConfigured) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
        <div className="bg-white w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden border-2 border-red-500 my-auto">
          <div className="bg-red-700 text-white p-6">
            <div className="flex items-center gap-3">
              <ShieldAlert className="w-8 h-8 text-yellow-300" />
              <div>
                <h2 className="text-xl font-black">Configurare Administrator Suprem</h2>
                <p className="text-xs text-red-100">Protejează Pitești Bazar de hoți și anunțuri false.</p>
              </div>
            </div>
          </div>

          <form onSubmit={handleCompleteSetup} className="p-6 space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Email Administrator
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                <input
                  type="email"
                  required
                  value={setupEmail}
                  onChange={(e) => setSetupEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 font-semibold text-sm outline-none focus:border-red-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Telefon Administrator
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                <input
                  type="tel"
                  required
                  value={setupPhone}
                  onChange={(e) => setSetupPhone(e.target.value)}
                  className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 font-semibold text-sm outline-none focus:border-red-600"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Alege Parola Secretă de Administrator (minim 8 caractere)
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                <input
                  type="password"
                  required
                  value={setupPassword}
                  onChange={(e) => setSetupPassword(e.target.value)}
                  placeholder="minim 8 caractere (litere și cifre)"
                  className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 font-semibold text-sm outline-none focus:border-red-600"
                />
              </div>
              {setupPassword && (
                <div className="mt-1 flex items-center justify-between text-[11px]">
                  <span>Complexitate: <strong className={getPasswordStrength(setupPassword).color}>{getPasswordStrength(setupPassword).text}</strong></span>
                  <span className="text-slate-400">{setupPassword.length} caractere</span>
                </div>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Preț promovare anunț (lei)
              </label>
              <input
                type="number"
                min="1"
                required
                value={setupPromoPrice}
                onChange={(e) => setSetupPromoPrice(Number(e.target.value))}
                className="w-full px-3 py-2.5 rounded-lg border border-slate-300 font-bold text-sm outline-none focus:border-red-600"
              />
            </div>

            <div className="pt-3">
              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-red-700 hover:bg-red-800 text-white font-black text-base shadow-lg transition active:scale-98 cursor-pointer"
              >
                Salvează și intră în Panoul de Control
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  // Login prompt if configured but logged out
  if (!isAdminLoggedIn) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto">
        <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden border border-slate-200 my-auto">
          <div className="bg-[#002f34] text-white p-5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <ShieldAlert className="w-6 h-6 text-[#23e5db]" />
              <h3 className="text-lg font-black">Autentificare Administrator</h3>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-300 hover:text-white rounded-lg cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleLoginSubmit} className="p-6 space-y-4">
            {loginError && (
              <div className="p-3 bg-rose-50 text-rose-800 text-xs font-semibold rounded-lg border border-rose-200 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Email Administrator
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                <input
                  type="email"
                  required
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  placeholder="adresa@email.ro"
                  className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 font-semibold text-sm outline-none focus:border-[#002f34]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1">
                Parolă Administrator
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                <input
                  type="password"
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 font-semibold text-sm outline-none focus:border-[#002f34]"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl bg-[#002f34] hover:bg-[#001d21] text-white font-black text-sm shadow-lg transition active:scale-98 cursor-pointer flex items-center justify-center gap-2"
            >
              <ShieldAlert className="w-4 h-4 text-[#23e5db]" />
              <span>Intră în Panoul Anti-Țepe</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="w-full text-xs text-slate-500 hover:text-slate-800 py-1 cursor-pointer"
            >
              ← Înapoi pe site
            </button>
          </form>
        </div>
      </div>
    );
  }

  // --- FULL SUPREME ADMIN DASHBOARD ---
  const pendingAds = ads.filter((a) => a.status === 'pending');
  const unresolvedReports = reports.filter((r) => !r.isResolved);
  const promotedCount = ads.filter((a) => a.isPromoted).length;

  return (
    <div className="fixed inset-0 z-50 bg-[#001417] text-slate-100 flex flex-col overflow-hidden">
      
      {/* Top Admin Navbar */}
      <div className="bg-[#002024] border-b border-[#00383e] px-4 sm:px-6 py-3 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-500 to-amber-500 text-white flex items-center justify-center font-black text-xl shadow-md">
            🛡️
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-base sm:text-lg tracking-tight text-white">
                Panou Anti-Țeapă & Administrare
              </span>
              <span className="text-[10px] font-black bg-rose-600 text-white px-2 py-0.5 rounded-full uppercase">
                Admin Suprem
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Conectat: <strong className="text-slate-200">{adminConfig.email}</strong> • Pitești, Mioveni, Curtea de Argeș
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 text-[#23e5db] font-bold text-xs transition cursor-pointer"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            <span>Mergi pe site</span>
          </button>

          <button
            onClick={onAdminLogout}
            className="px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 font-bold text-xs transition cursor-pointer"
          >
            Ieși din Admin
          </button>
        </div>
      </div>

      {/* Action Notification Toast */}
      {actionSuccessNotice && (
        <div className="bg-emerald-600 text-white py-2 px-4 text-center text-xs font-black shadow-md flex items-center justify-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>{actionSuccessNotice}</span>
        </div>
      )}

      {/* Scrollable Main Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 max-w-7xl mx-auto w-full">
        
        {/* Anti-Scam Urgent Alert Banner if there are pending reports or unapproved ads */}
        {(unresolvedReports.length > 0 || pendingAds.length > 0) && (
          <div className="bg-gradient-to-r from-rose-950/80 to-amber-950/80 border-2 border-rose-500/80 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <AlertOctagon className="w-7 h-7 text-rose-400 shrink-0 animate-pulse" />
              <div>
                <h4 className="font-black text-white text-sm sm:text-base">
                  Acțiuni necesare pentru siguranța vizitatorilor:
                </h4>
                <p className="text-xs text-slate-300">
                  {unresolvedReports.length > 0 && `• ${unresolvedReports.length} sesizări de țeapă de la vizitatori `}
                  {pendingAds.length > 0 && `• ${pendingAds.length} anunțuri noi în așteptare de aprobare`}
                </p>
              </div>
            </div>

            <div className="flex gap-2">
              {unresolvedReports.length > 0 && (
                <button
                  onClick={() => setActiveTab('reports')}
                  className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-lg transition cursor-pointer"
                >
                  Vezi Raportările ({unresolvedReports.length})
                </button>
              )}
              {pendingAds.length > 0 && (
                <button
                  onClick={() => setActiveTab('pending')}
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs font-black rounded-lg transition cursor-pointer"
                >
                  Aprobă Anunțurile ({pendingAds.length})
                </button>
              )}
            </div>
          </div>
        )}

        {/* 4 Stats KPI Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          <div className="bg-[#00252a] p-4 rounded-2xl border border-[#004149] flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                Sesizări Țeapă
              </span>
              <span className="text-2xl sm:text-3xl font-black text-rose-400 mt-1 block">
                {reports.length}
              </span>
              <span className="text-[11px] text-rose-300">
                {unresolvedReports.length} nerezolvate
              </span>
            </div>
            <div className="w-12 h-12 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>
          </div>

          <div className="bg-[#00252a] p-4 rounded-2xl border border-[#004149] flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                În Așteptare Aprobare
              </span>
              <span className="text-2xl sm:text-3xl font-black text-amber-400 mt-1 block">
                {pendingAds.length}
              </span>
              <span className="text-[11px] text-amber-300">
                Verificare manuală admin
              </span>
            </div>
            <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Clock className="w-6 h-6" />
            </div>
          </div>

          <div className="bg-[#00252a] p-4 rounded-2xl border border-[#004149] flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                Hoți pe Lista Neagră
              </span>
              <span className="text-2xl sm:text-3xl font-black text-red-500 mt-1 block">
                {blacklistedPhones.length}
              </span>
              <span className="text-[11px] text-slate-400">
                Numere blocate definitiv
              </span>
            </div>
            <div className="w-12 h-12 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center">
              <Ban className="w-6 h-6" />
            </div>
          </div>

          <div className="bg-[#00252a] p-4 rounded-2xl border border-[#004149] flex items-center justify-between">
            <div>
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">
                Încasări Promovări
              </span>
              <span className="text-2xl sm:text-3xl font-black text-emerald-400 mt-1 block">
                {adminConfig.totalRevenue + promotedCount * adminConfig.promoPrice} LEI
              </span>
              <span className="text-[11px] text-slate-400">
                {promotedCount} anunțuri promovate
              </span>
            </div>
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <DollarSign className="w-6 h-6" />
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-[#003d42] gap-2 overflow-x-auto scrollbar-none pb-1">
          <button
            onClick={() => setActiveTab('reports')}
            className={`py-3 px-4 font-bold text-xs sm:text-sm border-b-2 transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'reports'
                ? 'border-rose-500 text-rose-400 bg-rose-500/10 rounded-t-lg'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertTriangle className="w-4 h-4 text-rose-500" />
            <span>Raportări Țepe ({reports.length})</span>
            {unresolvedReports.length > 0 && (
              <span className="ml-1 px-1.5 py-0.5 rounded-full bg-rose-600 text-white text-[10px] font-black">
                {unresolvedReports.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('pending')}
            className={`py-3 px-4 font-bold text-xs sm:text-sm border-b-2 transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'pending'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10 rounded-t-lg'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Clock className="w-4 h-4 text-amber-400" />
            <span>Aprobare Anunțuri ({pendingAds.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('blacklist')}
            className={`py-3 px-4 font-bold text-xs sm:text-sm border-b-2 transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'blacklist'
                ? 'border-red-500 text-red-400 bg-red-500/10 rounded-t-lg'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Ban className="w-4 h-4 text-red-400" />
            <span>Lista Neagră ({blacklistedPhones.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('ads')}
            className={`py-3 px-4 font-bold text-xs sm:text-sm border-b-2 transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'ads'
                ? 'border-[#23e5db] text-[#23e5db] bg-teal-500/10 rounded-t-lg'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>Toate Anunțurile ({ads.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('users')}
            className={`py-3 px-4 font-bold text-xs sm:text-sm border-b-2 transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'users'
                ? 'border-[#23e5db] text-[#23e5db] bg-teal-500/10 rounded-t-lg'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Utilizatori ({users.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`py-3 px-4 font-bold text-xs sm:text-sm border-b-2 transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'settings'
                ? 'border-[#23e5db] text-[#23e5db] bg-teal-500/10 rounded-t-lg'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Setări</span>
          </button>
        </div>

        {/* TAB 1: REPORTS (RAPORTARI TEPE) */}
        {activeTab === 'reports' && (
          <div className="space-y-4">
            <div className="bg-[#00252a] p-4 rounded-xl border border-[#004149] flex items-center justify-between">
              <div>
                <h3 className="font-black text-white text-base">
                  Sesizări de la vizitatori despre anunțuri false sau tentative de țeapă
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Verifică sesizările și folosește butoanele roșii pentru a bloca definitiv numerele suspecte.
                </p>
              </div>
            </div>

            {reports.length > 0 ? (
              <div className="space-y-3">
                {reports.map((rep) => {
                  const reportedAd = ads.find((a) => a.id === rep.adId);
                  const isBlocked = blacklistedPhones.some((b) => cleanPhone(b.phone) === cleanPhone(rep.sellerPhone));

                  return (
                    <div
                      key={rep.id}
                      className={`p-4 rounded-2xl border-2 transition ${
                        rep.isResolved
                          ? 'bg-[#001d21] border-slate-700 opacity-70'
                          : 'bg-[#00282e] border-rose-500/80 shadow-lg'
                      }`}
                    >
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        <div className="space-y-1.5 flex-1">
                          <div className="flex items-center gap-2">
                            <span className="px-2.5 py-0.5 rounded-full bg-rose-600 text-white text-[11px] font-black uppercase flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3 text-yellow-300" />
                              Motiv: {rep.reason}
                            </span>
                            <span className="text-xs text-slate-400">
                              {formatTimeAgo(rep.createdAt)}
                            </span>
                            {isBlocked && (
                              <span className="px-2 py-0.5 rounded bg-red-950 text-red-300 border border-red-700 text-[10px] font-black uppercase">
                                Număr deja blocat
                              </span>
                            )}
                          </div>

                          <h4 className="font-bold text-white text-base">
                            Anunț: {rep.adTitle}
                          </h4>

                          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300">
                            <span>Vânzător suspect: <strong className="text-white">{rep.sellerName}</strong></span>
                            <span>•</span>
                            <span>Telefon: <strong className="font-mono text-[#23e5db]">{rep.sellerPhone}</strong></span>
                            {rep.reporterPhone && (
                              <>
                                <span>•</span>
                                <span>Raportat de tel: <span className="font-mono text-slate-400">{rep.reporterPhone}</span></span>
                              </>
                            )}
                          </div>

                          {rep.details && (
                            <div className="p-2.5 bg-black/40 rounded-xl border border-white/10 text-xs text-slate-200 italic mt-2">
                              „{rep.details}”
                            </div>
                          )}
                        </div>

                        {/* Direct Anti-Scam Admin Actions */}
                        <div className="flex flex-wrap lg:flex-col items-end gap-2 shrink-0">
                          {/* Big Red Button: Blocheaza Definitiv */}
                          {!isBlocked && (
                            <button
                              onClick={() => handleBlockDefinitively(rep.sellerPhone, rep.sellerName, rep.id)}
                              className="px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-black rounded-xl shadow-lg transition cursor-pointer flex items-center gap-1.5 active:scale-95"
                            >
                              <Ban className="w-4 h-4" />
                              <span>BLOCHEAZĂ DEFINITIV</span>
                            </button>
                          )}

                          {/* Delete all ads of scammer */}
                          <button
                            onClick={() => handleDeleteAllAdsOfUser(rep.sellerPhone)}
                            className="px-3 py-2 bg-rose-950 hover:bg-rose-900 border border-rose-600 text-rose-200 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Șterge toate anunțurile acestui hoț</span>
                          </button>

                          {/* Resolve / False alarm */}
                          {!rep.isResolved && (
                            <button
                              onClick={() => handleResolveReport(rep.id)}
                              className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-slate-300 text-xs font-semibold rounded-lg transition cursor-pointer"
                            >
                              Marchează ca rezolvat
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12 bg-[#00252a] rounded-2xl border border-[#004149]">
                <ShieldCheck className="w-12 h-12 text-emerald-400 mx-auto mb-2" />
                <h4 className="font-bold text-white text-base">Nicio sesizare activă</h4>
                <p className="text-xs text-slate-400 mt-1">
                  Comunitatea Pitești Bazar este curată și sigură.
                </p>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: PENDING ADS (APROBARE ANUNTURI NOI) */}
        {activeTab === 'pending' && (
          <div className="space-y-4">
            <div className="bg-[#00252a] p-4 rounded-xl border border-[#004149] flex items-center justify-between">
              <div>
                <h3 className="font-black text-white text-base">
                  Anunțuri în așteptare de aprobare ({pendingAds.length})
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Toate anunțurile noi stau în așteptare până le verifici tu. Doar cele aprobate apar vizitatorilor.
                </p>
              </div>
            </div>

            {pendingAds.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {pendingAds.map((ad) => (
                  <div
                    key={ad.id}
                    className="bg-[#00252a] rounded-2xl border-2 border-amber-500/50 p-4 flex flex-col justify-between space-y-4"
                  >
                    <div className="flex gap-3">
                      <img
                        src={ad.images[0] || 'https://images.unsplash.com/photo-1584824486509-112e4181ff6b?w=800&auto=format&fit=crop&q=80'}
                        alt=""
                        className="w-24 h-20 rounded-xl object-cover bg-slate-900 shrink-0"
                      />
                      <div className="flex-1">
                        <span className="text-[11px] font-bold text-amber-400 uppercase block">
                          {ad.category} • {ad.city}
                        </span>
                        <h4 className="font-bold text-white text-base line-clamp-1">
                          {ad.title}
                        </h4>
                        <span className="font-black text-lg text-[#23e5db] block mt-0.5">
                          {formatPrice(ad.price, ad.currency, ad.isFree)}
                        </span>
                        <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                          {ad.description}
                        </p>
                      </div>
                    </div>

                    <div className="pt-3 border-t border-[#003d42] flex items-center justify-between">
                      <div className="text-xs text-slate-300">
                        <span>Vânzător: <strong className="text-white">{ad.sellerName}</strong></span>
                        <div className="font-mono text-[#23e5db]">{ad.phone}</div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleRejectAd(ad.id)}
                          className="px-3 py-2 bg-rose-600/30 hover:bg-rose-600 text-rose-300 hover:text-white rounded-xl text-xs font-bold transition cursor-pointer"
                        >
                          Respinge
                        </button>
                        <button
                          onClick={() => handleApproveAd(ad.id)}
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow transition cursor-pointer flex items-center gap-1.5"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Aprobă Anunțul</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-[#00252a] rounded-2xl border border-[#004149]">
                <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-2" />
                <h4 className="font-bold text-white text-base">Toate anunțurile au fost verificate!</h4>
                <p className="text-xs text-slate-400 mt-1">
                  Nu există anunțuri în așteptare de aprobare în acest moment.
                </p>
              </div>
            )}
          </div>
        )}

        {/* TAB 3: BLACKLIST (LISTA NEAGRA HOȚI) */}
        {activeTab === 'blacklist' && (
          <div className="space-y-4">
            <div className="bg-[#00252a] p-4 rounded-xl border border-[#004149]">
              <h3 className="font-black text-white text-base">
                Lista Neagră – Numere de telefon blocate definitiv ({blacklistedPhones.length})
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Utilizatorii de pe această listă nu se mai pot autentifica și nu pot crea conturi noi cu aceste numere.
              </p>
            </div>

            {blacklistedPhones.length > 0 ? (
              <div className="bg-[#002024] rounded-2xl border border-[#00383e] overflow-hidden">
                <table className="w-full text-left text-xs sm:text-sm">
                  <thead className="bg-[#00171a] text-slate-400 uppercase text-[11px] font-bold border-b border-[#00383e]">
                    <tr>
                      <th className="p-3.5">Număr Telefon Blocat</th>
                      <th className="p-3.5">Nume / Identificare</th>
                      <th className="p-3.5">Motiv Blocare</th>
                      <th className="p-3.5">Data Blocării</th>
                      <th className="p-3.5 text-right">Acțiune</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#00383e]">
                    {blacklistedPhones.map((b) => (
                      <tr key={b.phone} className="hover:bg-white/5">
                        <td className="p-3.5 font-mono font-black text-red-400">
                          {b.phone}
                        </td>
                        <td className="p-3.5 font-semibold text-white">
                          {b.name || 'Utilizator raportat'}
                        </td>
                        <td className="p-3.5 text-xs text-slate-300">
                          {b.reason}
                        </td>
                        <td className="p-3.5 text-xs text-slate-400">
                          {formatTimeAgo(b.blockedAt)}
                        </td>
                        <td className="p-3.5 text-right">
                          <button
                            onClick={() => handleUnblacklist(b.phone)}
                            className="px-2.5 py-1 bg-white/10 hover:bg-emerald-600 hover:text-white text-slate-300 text-xs font-bold rounded-lg transition cursor-pointer"
                          >
                            Deblochează
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-12 bg-[#00252a] rounded-2xl border border-[#004149]">
                <Ban className="w-12 h-12 text-slate-500 mx-auto mb-2" />
                <h4 className="font-bold text-white text-base">Lista neagră este goală</h4>
                <p className="text-xs text-slate-400 mt-1">
                  Când identifici un hoț sau anunț fals, folosește butonul „BLOCHEAZĂ DEFINITIV”.
                </p>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: ALL ADS */}
        {activeTab === 'ads' && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 bg-[#002024] p-3 rounded-xl border border-[#00383e]">
              <Search className="w-5 h-5 text-slate-400 shrink-0 ml-1" />
              <input
                type="text"
                value={adsSearchQuery}
                onChange={(e) => setAdsSearchQuery(e.target.value)}
                placeholder="Caută în anunțuri după titlu, oraș, vânzător sau telefon..."
                className="w-full bg-transparent text-sm text-white placeholder-slate-400 outline-none"
              />
            </div>

            <div className="bg-[#002024] rounded-2xl border border-[#00383e] overflow-hidden">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-[#00171a] text-slate-400 uppercase text-[11px] font-bold border-b border-[#00383e]">
                  <tr>
                    <th className="p-3.5">Anunț</th>
                    <th className="p-3.5">Preț</th>
                    <th className="p-3.5">Oraș</th>
                    <th className="p-3.5">Vânzător</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Acțiuni Admin</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#00383e]">
                  {ads
                    .filter((a) => !adsSearchQuery || a.title.toLowerCase().includes(adsSearchQuery.toLowerCase()) || a.phone.includes(adsSearchQuery))
                    .map((ad) => (
                      <tr key={ad.id} className="hover:bg-white/5">
                        <td className="p-3.5">
                          <div className="flex items-center gap-3">
                            <img
                              src={ad.images[0] || 'https://images.unsplash.com/photo-1584824486509-112e4181ff6b?w=800&auto=format&fit=crop&q=80'}
                              alt=""
                              className="w-12 h-10 rounded-lg object-cover bg-slate-900 shrink-0"
                            />
                            <div>
                              <span className="font-bold text-white block line-clamp-1">{ad.title}</span>
                              <span className="text-[11px] text-slate-400">{ad.category}</span>
                            </div>
                          </div>
                        </td>
                        <td className="p-3.5 font-bold text-[#23e5db] whitespace-nowrap">
                          {formatPrice(ad.price, ad.currency, ad.isFree)}
                        </td>
                        <td className="p-3.5 text-slate-300 whitespace-nowrap">
                          {ad.city}
                        </td>
                        <td className="p-3.5 text-slate-300">
                          <div className="font-semibold text-white">{ad.sellerName}</div>
                          <div className="text-[11px] text-slate-400 font-mono">{ad.phone}</div>
                        </td>
                        <td className="p-3.5 whitespace-nowrap">
                          {ad.status === 'pending' ? (
                            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold text-[11px] border border-amber-500/40">
                              În așteptare
                            </span>
                          ) : ad.isPromoted ? (
                            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold text-[11px] border border-amber-500/40">
                              ★ Promovat
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[11px]">
                              Aprobat
                            </span>
                          )}
                        </td>
                        <td className="p-3.5 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            {ad.status === 'pending' && (
                              <button
                                onClick={() => handleApproveAd(ad.id)}
                                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-bold"
                              >
                                Aprobă
                              </button>
                            )}

                            <button
                              onClick={() => handleTogglePromote(ad.id)}
                              className={`px-2 py-1 rounded text-xs font-bold transition cursor-pointer ${
                                ad.isPromoted
                                  ? 'bg-amber-600 text-white'
                                  : 'bg-white/10 hover:bg-white/20 text-yellow-300'
                              }`}
                            >
                              {ad.isPromoted ? 'Scoate Promovare' : 'Promovează'}
                            </button>

                            <button
                              onClick={() => handleRejectAd(ad.id)}
                              className="p-1.5 rounded bg-rose-600/30 hover:bg-rose-600 text-rose-300 hover:text-white transition cursor-pointer"
                              title="Șterge anunțul"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 5: USERS */}
        {activeTab === 'users' && (
          <div className="space-y-4">
            <div className="bg-[#002024] rounded-2xl border border-[#00383e] overflow-hidden">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-[#00171a] text-slate-400 uppercase text-[11px] font-bold border-b border-[#00383e]">
                  <tr>
                    <th className="p-3.5">Utilizator</th>
                    <th className="p-3.5">Telefon</th>
                    <th className="p-3.5">Parolă</th>
                    <th className="p-3.5">Oraș</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Acțiuni Anti-Țeapă</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#00383e]">
                  {users.map((u) => (
                    <tr key={u.id} className="hover:bg-white/5">
                      <td className="p-3.5 font-bold text-white">
                        {u.name}
                      </td>
                      <td className="p-3.5 font-mono text-[#23e5db] font-bold">
                        {u.phone}
                      </td>
                      <td className="p-3.5 font-mono text-amber-300 bg-amber-500/10 px-2 py-1 rounded inline-block my-2">
                        {u.password}
                      </td>
                      <td className="p-3.5 text-slate-300">
                        {u.city}
                      </td>
                      <td className="p-3.5">
                        {u.isBlocked ? (
                          <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 font-bold text-[11px] border border-rose-500/40">
                            Blocat
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold text-[11px]">
                            Activ
                          </span>
                        )}
                      </td>
                      <td className="p-3.5 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleBlockDefinitively(u.phone, u.name)}
                            className="px-2.5 py-1 bg-red-600/30 hover:bg-red-600 text-red-300 hover:text-white rounded text-xs font-bold transition cursor-pointer"
                          >
                            {u.isBlocked ? 'Re-Blochează' : 'Blochează Definitiv'}
                          </button>
                          <button
                            onClick={() => handleDeleteAllAdsOfUser(u.phone)}
                            className="px-2.5 py-1 bg-rose-950 text-rose-300 hover:bg-rose-900 rounded text-xs font-bold border border-rose-700 transition cursor-pointer"
                          >
                            Șterge Anunțurile
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 6: SETTINGS */}
        {activeTab === 'settings' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-[#00252a] rounded-2xl p-5 border border-[#004149] space-y-4">
              <div className="flex items-center gap-2 text-white font-bold text-base">
                <DollarSign className="w-5 h-5 text-emerald-400" />
                <span>Preț Promovare Anunț</span>
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min="1"
                  defaultValue={adminConfig.promoPrice}
                  id="promoPriceInput2"
                  className="w-32 px-4 py-3 rounded-xl bg-[#00171a] border border-[#00383e] text-xl font-black text-emerald-400 outline-none text-center"
                />
                <button
                  type="button"
                  onClick={() => {
                    const el = document.getElementById('promoPriceInput2') as HTMLInputElement;
                    if (el && Number(el.value) > 0) {
                      handleSavePromoPrice(Number(el.value));
                    }
                  }}
                  className="px-4 py-3 bg-[#23e5db] hover:bg-[#3bf5eb] text-[#002f34] font-black rounded-xl text-sm transition cursor-pointer"
                >
                  Setează Preț
                </button>
              </div>
            </div>

            <div className="bg-[#00252a] rounded-2xl p-5 border border-[#004149] space-y-4">
              <div className="flex items-center gap-2 text-white font-bold text-base">
                <RefreshCw className="w-5 h-5 text-amber-400" />
                <span>Resetare Sistem de Test</span>
              </div>
              <button
                type="button"
                onClick={onResetAllData}
                className="w-full py-3 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs font-bold transition cursor-pointer"
              >
                Resetează datele la setările inițiale
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
