import React, { useState, useEffect } from 'react';
import { 
  X, 
  Upload, 
  Image as ImageIcon, 
  Plus, 
  AlertCircle,
  MapPin,
  Phone,
  User as UserIcon,
  Sparkles,
  ShieldCheck
} from 'lucide-react';
import { Ad, LocationCity, User } from '../types';
import { CITIES, CATEGORIES, NEIGHBORHOODS, PRESET_PHOTOS } from '../data/seedAds';

interface AddAdModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddAd: (newAd: Ad) => void;
  currentUser: User | null;
  defaultCity?: LocationCity;
}

export const AddAdModal: React.FC<AddAdModalProps> = ({
  isOpen,
  onClose,
  onAddAd,
  currentUser,
  defaultCity = 'Pitești',
}) => {
  if (!isOpen) return null;

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState(CATEGORIES[1] || 'Auto & Moto');
  const [city, setCity] = useState<LocationCity>(currentUser?.city || defaultCity);
  const [neighborhood, setNeighborhood] = useState('');
  const [price, setPrice] = useState<string>('');
  const [currency, setCurrency] = useState<'lei' | '€'>('lei');
  const [isNegotiable, setIsNegotiable] = useState(true);
  const [isFree, setIsFree] = useState(false);
  const [description, setDescription] = useState('');
  const [sellerName, setSellerName] = useState(currentUser?.name || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  
  // Image
  const [imageUrl, setImageUrl] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Sync with current user if changes
  useEffect(() => {
    if (currentUser) {
      setSellerName(currentUser.name);
      setPhone(currentUser.phone);
      setCity(currentUser.city);
    }
  }, [currentUser]);

  // File upload handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMsg('Te rugăm să alegi un fișier de tip imagine (JPG, PNG, WebP).');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setErrorMsg('Imaginea este prea mare. Alege o imagine sub 5MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (typeof event.target?.result === 'string') {
        setImageUrl(event.target.result);
        setErrorMsg(null);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSelectPreset = (url: string) => {
    setImageUrl(url);
    setErrorMsg(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    // Validation
    if (!title.trim() || title.trim().length < 4) {
      setErrorMsg('Te rugăm să introduci un titlu de minim 4 caractere.');
      return;
    }

    if (!isFree && (!price || Number(price) < 0)) {
      setErrorMsg('Te rugăm să introduci un preț valid sau să bifezi "Gratuit".');
      return;
    }

    if (!sellerName.trim()) {
      setErrorMsg('Te rugăm să introduci numele tău de contact.');
      return;
    }

    if (!phone.trim() || phone.replace(/\D/g, '').length < 8) {
      setErrorMsg('Te rugăm să introduci un număr de telefon valid (ex: 0722 123 456).');
      return;
    }

    // Default image if none uploaded
    let finalImage = imageUrl.trim();
    if (!finalImage) {
      const foundPreset = PRESET_PHOTOS.find((p) => {
        if (category.includes('Auto') && p.label.includes('Auto')) return true;
        if (category.includes('Imobiliare') && p.label.includes('Apartament')) return true;
        if (category.includes('Electronice') && p.label.includes('Telefon')) return true;
        return false;
      });
      finalImage = foundPreset ? foundPreset.url : PRESET_PHOTOS[0].url;
    }

    // Notice: status is 'pending' for manual approval by admin!
    const newAd: Ad = {
      id: 'ad-' + Date.now(),
      title: title.trim(),
      description: description.trim() || 'Fără descriere suplimentară. Pentru mai multe detalii contactați vânzătorul la numărul de telefon afișat.',
      price: isFree ? 0 : Number(price),
      currency: currency,
      isNegotiable: isNegotiable && !isFree,
      isFree: isFree,
      city: city,
      neighborhood: neighborhood.trim() || undefined,
      category: category,
      images: [finalImage],
      sellerName: sellerName.trim(),
      phone: phone.trim(),
      userId: currentUser?.id || 'guest',
      createdAt: new Date().toISOString(),
      status: 'pending', // Pending manual admin verification
      isFeatured: false,
      isPromoted: false,
      viewsCount: 1,
      isUserCreated: true,
      reportsCount: 0,
    };

    onAddAd(newAd);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div 
        className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[92vh] border border-slate-200 animate-in fade-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-[#002f34] flex items-center gap-2">
              <Plus className="w-6 h-6 text-[#23e5db] bg-[#002f34] rounded-lg p-1" />
              Adaugă anunț gratis
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Anunțul tău va fi verificat de administratorul din Pitești înainte de publicare
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg transition cursor-pointer"
            title="Închide"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form Body (Scrollable) */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 overflow-y-auto flex-1 space-y-5">
          
          {errorMsg && (
            <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm font-medium flex items-center gap-2.5">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Security Guarantee Notice */}
          <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-200 text-xs text-emerald-950 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              <strong>Garanție de siguranță:</strong> Pentru a elimina complet tentativele de țeapă, anunțul tău ajunge întâi la administrator pentru verificare rapidă.
            </span>
          </div>

          {/* 1. Titlu anunț */}
          <div>
            <label className="block text-sm font-bold text-slate-900 mb-1">
              Titlu anunț <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="ex: Vând Dacia Duster 4x4 sau Apartament 2 camere Trivale"
              className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-[#002f34] focus:ring-2 focus:ring-[#23e5db]/30 text-slate-900 placeholder-slate-400 text-base font-medium outline-none transition"
              maxLength={90}
            />
            <div className="flex justify-between text-xs text-slate-400 mt-1">
              <span>Fii cât mai descriptiv</span>
              <span>{title.length}/90</span>
            </div>
          </div>

          {/* 2. Categorie */}
          <div>
            <label className="block text-sm font-bold text-slate-900 mb-1">
              Categorie <span className="text-rose-500">*</span>
            </label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-[#002f34] focus:ring-2 focus:ring-[#23e5db]/30 text-slate-900 font-medium text-base outline-none bg-white cursor-pointer"
            >
              {CATEGORIES.filter((c) => c !== 'Toate categoriile').map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* 3. Locație */}
          <div className="space-y-2">
            <label className="block text-sm font-bold text-slate-900">
              Oraș în Argeș <span className="text-rose-500">*</span>
            </label>
            
            <div className="grid grid-cols-3 gap-2">
              {CITIES.map((c) => {
                const isSelected = city === c;
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => {
                      setCity(c);
                      setNeighborhood('');
                    }}
                    className={`py-3 px-2 rounded-xl border-2 font-bold text-center text-sm sm:text-base transition cursor-pointer flex flex-col items-center justify-center gap-1 ${
                      isSelected
                        ? 'border-[#002f34] bg-[#002f34] text-white shadow-md'
                        : 'border-slate-200 bg-slate-50 text-slate-700 hover:border-slate-300 hover:bg-white'
                    }`}
                  >
                    <MapPin className={`w-4 h-4 ${isSelected ? 'text-[#23e5db]' : 'text-slate-400'}`} />
                    <span className="truncate">{c}</span>
                  </button>
                );
              })}
            </div>

            <div className="mt-2">
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Cartier / Zonă (opțional):
              </label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {NEIGHBORHOODS[city]?.map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setNeighborhood(n)}
                    className={`text-xs px-2.5 py-1 rounded-md transition cursor-pointer ${
                      neighborhood === n
                        ? 'bg-[#23e5db] text-[#002f34] font-bold'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {n}
                  </button>
                ))}
              </div>
              <input
                type="text"
                value={neighborhood}
                onChange={(e) => setNeighborhood(e.target.value)}
                placeholder="sau scrie alt cartier/zonă..."
                className="w-full px-3.5 py-2 rounded-lg border border-slate-300 text-sm text-slate-800 placeholder-slate-400 outline-none focus:border-[#002f34]"
              />
            </div>
          </div>

          {/* 4. Preț */}
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-bold text-slate-900">
                Preț {isFree ? '(Gratuit)' : ''} <span className="text-rose-500">*</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-[#002f34]">
                <input
                  type="checkbox"
                  checked={isFree}
                  onChange={(e) => setIsFree(e.target.checked)}
                  className="w-4 h-4 rounded text-[#002f34] focus:ring-[#23e5db] cursor-pointer"
                />
                Ofer gratuit / Donez
              </label>
            </div>

            {!isFree && (
              <div className="flex gap-2">
                <input
                  type="number"
                  min="0"
                  step="any"
                  required={!isFree}
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  placeholder="ex: 450"
                  className="flex-1 px-4 py-3 rounded-xl border border-slate-300 focus:border-[#002f34] focus:ring-2 focus:ring-[#23e5db]/30 text-slate-900 font-bold text-lg outline-none bg-white"
                />

                <div className="flex rounded-xl overflow-hidden border border-slate-300 bg-white">
                  <button
                    type="button"
                    onClick={() => setCurrency('lei')}
                    className={`px-4 py-3 font-bold text-sm transition cursor-pointer ${
                      currency === 'lei' ? 'bg-[#002f34] text-white' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    LEI
                  </button>
                  <button
                    type="button"
                    onClick={() => setCurrency('€')}
                    className={`px-4 py-3 font-bold text-sm transition cursor-pointer ${
                      currency === '€' ? 'bg-[#002f34] text-white' : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    EUR (€)
                  </button>
                </div>
              </div>
            )}

            {!isFree && (
              <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
                <input
                  type="checkbox"
                  checked={isNegotiable}
                  onChange={(e) => setIsNegotiable(e.target.checked)}
                  className="w-4 h-4 rounded text-[#002f34] focus:ring-[#23e5db] cursor-pointer"
                />
                Preț negociabil
              </label>
            )}
          </div>

          {/* 5. Poza anunțului */}
          <div className="space-y-3">
            <label className="block text-sm font-bold text-slate-900">
              Fotografie anunț
            </label>

            {imageUrl ? (
              <div className="relative aspect-[16/9] w-full max-w-md mx-auto rounded-xl overflow-hidden border-2 border-[#23e5db] shadow-md bg-slate-100">
                <img
                  src={imageUrl}
                  alt="Previzualizare poză"
                  className="w-full h-full object-cover"
                />
                <button
                  type="button"
                  onClick={() => setImageUrl('')}
                  className="absolute top-2 right-2 p-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-full shadow-lg transition cursor-pointer"
                  title="Șterge poza"
                >
                  <X className="w-4 h-4" />
                </button>
                <div className="absolute bottom-2 left-2 bg-black/70 backdrop-blur-xs text-white text-xs px-2.5 py-1 rounded">
                  ✓ Poză încărcată
                </div>
              </div>
            ) : (
              <div className="border-2 border-dashed border-slate-300 hover:border-[#002f34] rounded-2xl p-6 text-center bg-slate-50/60 hover:bg-slate-50 transition cursor-pointer relative group">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                />
                <div className="flex flex-col items-center justify-center gap-2">
                  <div className="w-12 h-12 rounded-full bg-[#002f34]/10 group-hover:bg-[#002f34] text-[#002f34] group-hover:text-white flex items-center justify-center transition-colors">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="font-bold text-slate-900 group-hover:text-[#002f34] text-sm sm:text-base">
                      Apasă pentru a alege o poză din telefon sau PC
                    </span>
                    <p className="text-xs text-slate-500 mt-0.5">
                      JPG, PNG, WebP până la 5MB
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div>
              <span className="text-xs text-slate-500 font-semibold block mb-1.5">
                Sau alege o poză rapidă de test:
              </span>
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
                {PRESET_PHOTOS.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSelectPreset(p.url)}
                    className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-medium whitespace-nowrap transition cursor-pointer"
                  >
                    <ImageIcon className="w-3.5 h-3.5 text-slate-500" />
                    <span>{p.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 6. Descriere */}
          <div>
            <label className="block text-sm font-bold text-slate-900 mb-1">
              Descriere detaliată
            </label>
            <textarea
              rows={4}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Descrie starea produsului, vechime, dotări, motivul vânzării..."
              className="w-full px-4 py-3 rounded-xl border border-slate-300 focus:border-[#002f34] focus:ring-2 focus:ring-[#23e5db]/30 text-slate-900 placeholder-slate-400 text-sm sm:text-base outline-none transition"
            />
          </div>

          {/* 7. Date de contact */}
          <div className="p-4 bg-emerald-50/60 rounded-xl border border-emerald-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-emerald-950 font-bold text-sm">
                <Phone className="w-4 h-4 text-emerald-700" />
                <span>Date de contact vânzător:</span>
              </div>
              {currentUser && (
                <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                  ✓ Din contul tău
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nume vânzător <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    required
                    value={sellerName}
                    onChange={(e) => setSellerName(e.target.value)}
                    placeholder="ex: Marian Niculescu"
                    className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 focus:border-[#002f34] text-slate-900 font-medium text-sm outline-none bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Număr de telefon <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="ex: 0722 123 456"
                    className="w-full pl-9 pr-3 py-2.5 rounded-lg border border-slate-300 focus:border-[#002f34] text-slate-900 font-bold text-sm outline-none bg-white"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Submit Big Button */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-[#22c55e] to-[#16a34a] hover:from-[#2ecc71] hover:to-[#1ebb5b] text-white font-black text-base sm:text-lg shadow-xl active:scale-98 transition flex items-center justify-center gap-2 cursor-pointer border border-emerald-400/30"
            >
              <Sparkles className="w-5 h-5 text-white" />
              <span>Trimite spre aprobare - GRATIS</span>
            </button>
            <p className="text-center text-xs text-slate-500 mt-2">
              🛡️ Anunțul va fi aprobat în câteva minute de administratorul din Pitești.
            </p>
          </div>

        </form>

      </div>
    </div>
  );
};
