import React from 'react';
import { Search, MapPin, X, ArrowRight } from 'lucide-react';
import { LocationCity } from '../types';
import { CITIES } from '../data/seedAds';

interface SearchBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCity: LocationCity | 'all';
  onCityChange: (city: LocationCity | 'all') => void;
  onClear: () => void;
  totalResults: number;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  searchQuery,
  onSearchChange,
  selectedCity,
  onCityChange,
  onClear,
  totalResults,
}) => {
  const getCityDisplay = () => {
    if (selectedCity === 'all') return 'Tot județul Argeș';
    return selectedCity;
  };

  const getPlaceholderText = () => {
    if (selectedCity === 'all') return 'Ce cauți în Pitești? (mașini, apartamente, telefoane...)';
    return `Ce cauți în ${selectedCity}?`;
  };

  return (
    <div className="bg-[#002f34] pb-8 pt-4 px-4 sm:px-6 lg:px-8 border-b border-[#002327]">
      <div className="max-w-4xl mx-auto">
        {/* Search Title */}
        <div className="text-center mb-4">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Ce cauți în <span className="text-[#23e5db] underline decoration-wavy decoration-[#23e5db]/40">Pitești</span> și împrejurimi?
          </h1>
          <p className="text-sm text-slate-300 mt-1">
            Găsește anunțuri verificate din Pitești, Mioveni și Curtea de Argeș
          </p>
        </div>

        {/* Big Search Bar Form */}
        <div className="bg-white rounded-2xl p-2 sm:p-2.5 shadow-2xl flex flex-col md:flex-row items-stretch gap-2 border-2 border-slate-200">
          
          {/* Main text input */}
          <div className="flex-1 flex items-center px-3 py-2 bg-slate-50/70 hover:bg-slate-50 rounded-xl transition-colors">
            <Search className="w-6 h-6 text-slate-400 shrink-0 mr-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder={getPlaceholderText()}
              className="w-full bg-transparent text-slate-800 placeholder-slate-400 font-medium text-base sm:text-lg focus:outline-none"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={onClear}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-200 transition"
                title="Șterge căutarea"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Location Selector */}
          <div className="flex items-center px-3 py-2 bg-slate-50/70 rounded-xl border border-slate-200 md:border-none min-w-[200px]">
            <MapPin className="w-5 h-5 text-[#002f34] shrink-0 mr-2" />
            <select
              value={selectedCity}
              onChange={(e) => onCityChange(e.target.value as LocationCity | 'all')}
              className="w-full bg-transparent text-slate-900 font-semibold text-sm sm:text-base focus:outline-none cursor-pointer"
            >
              <option value="all">Toate orașele (Argeș)</option>
              {CITIES.map((city) => (
                <option key={city} value={city}>
                  {city}
                </option>
              ))}
            </select>
          </div>

          {/* Big Search Button */}
          <button
            type="button"
            className="bg-[#002f34] hover:bg-[#001d21] text-white font-bold px-6 py-3.5 rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md hover:shadow-lg active:scale-98"
          >
            <span className="text-base">Caută</span>
            <ArrowRight className="w-4 h-4 text-[#23e5db]" />
          </button>
        </div>

        {/* Quick status bar below search */}
        <div className="mt-3 flex flex-wrap items-center justify-between text-xs sm:text-sm text-slate-300 px-1 gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-[#23e5db] animate-pulse"></span>
            <span>
              {totalResults} {totalResults === 1 ? 'anunț activ' : 'anunțuri active'} în {getCityDisplay()}
            </span>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span>Filtre rapide:</span>
            {CITIES.map((c) => (
              <button
                key={c}
                onClick={() => onCityChange(c)}
                className={`px-2 py-0.5 rounded transition ${
                  selectedCity === c
                    ? 'bg-[#23e5db] text-[#002f34] font-bold'
                    : 'bg-white/10 text-slate-200 hover:bg-white/20'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
