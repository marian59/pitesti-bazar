import React, { useState } from 'react';
import { X, Check, AlertCircle, Save } from 'lucide-react';
import { Ad, LocationCity } from '../types';
import { CITIES, CATEGORIES, NEIGHBORHOODS, PRESET_PHOTOS } from '../data/seedAds';

interface EditAdModalProps {
  ad: Ad | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedAd: Ad) => void;
}

export const EditAdModal: React.FC<EditAdModalProps> = ({
  ad,
  isOpen,
  onClose,
  onSave,
}) => {
  if (!isOpen || !ad) return null;

  const [title, setTitle] = useState(ad.title);
  const [category, setCategory] = useState(ad.category);
  const [city, setCity] = useState<LocationCity>(ad.city);
  const [neighborhood, setNeighborhood] = useState(ad.neighborhood || '');
  const [price, setPrice] = useState<string>(ad.price.toString());
  const [currency, setCurrency] = useState<'lei' | '€'>(ad.currency);
  const [isNegotiable, setIsNegotiable] = useState(ad.isNegotiable);
  const [isFree, setIsFree] = useState(ad.isFree || false);
  const [description, setDescription] = useState(ad.description);
  const [imageUrl, setImageUrl] = useState(ad.images[0] || '');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || title.trim().length < 4) {
      setErrorMsg('Titlul trebuie să aibă cel puțin 4 caractere.');
      return;
    }

    if (!isFree && (!price || Number(price) < 0)) {
      setErrorMsg('Introdu un preț valid.');
      return;
    }

    const updated: Ad = {
      ...ad,
      title: title.trim(),
      category,
      city,
      neighborhood: neighborhood.trim() || undefined,
      price: isFree ? 0 : Number(price),
      currency,
      isNegotiable: isNegotiable && !isFree,
      isFree,
      description: description.trim(),
      images: imageUrl ? [imageUrl] : ad.images,
    };

    onSave(updated);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
      <div 
        className="bg-white w-full max-w-xl rounded-2xl shadow-2xl overflow-hidden my-auto flex flex-col max-h-[90vh] border border-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 bg-slate-50">
          <h3 className="text-lg font-bold text-slate-900">
            Editează anunțul
          </h3>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4">
          {errorMsg && (
            <div className="p-3 rounded-lg bg-rose-50 text-rose-800 text-xs font-semibold">
              {errorMsg}
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Titlu</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg border border-slate-300 font-semibold text-sm outline-none focus:border-[#002f34]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Categorie</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm outline-none bg-white font-medium"
              >
                {CATEGORIES.filter((c) => c !== 'Toate categoriile').map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Oraș</label>
              <select
                value={city}
                onChange={(e) => setCity(e.target.value as LocationCity)}
                className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm outline-none bg-white font-medium"
              >
                {CITIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Preț</label>
            <div className="flex gap-2">
              <input
                type="number"
                disabled={isFree}
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="flex-1 px-3 py-2.5 rounded-lg border border-slate-300 font-bold text-sm outline-none"
              />
              <div className="flex border border-slate-300 rounded-lg overflow-hidden">
                <button
                  type="button"
                  onClick={() => setCurrency('lei')}
                  className={`px-3 py-2 font-bold text-xs ${currency === 'lei' ? 'bg-[#002f34] text-white' : 'bg-white'}`}
                >
                  LEI
                </button>
                <button
                  type="button"
                  onClick={() => setCurrency('€')}
                  className={`px-3 py-2 font-bold text-xs ${currency === '€' ? 'bg-[#002f34] text-white' : 'bg-white'}`}
                >
                  €
                </button>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Descriere</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg border border-slate-300 text-sm outline-none"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-[#002f34] hover:bg-[#001d21] text-white font-bold text-sm shadow transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <Save className="w-4 h-4 text-[#23e5db]" />
              <span>Salvează modificările</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
