import { Ad, User, AdminConfig, DailyStats, LocationCity, AdReport, BlacklistedPhone } from '../types';
import { INITIAL_ADS } from '../data/seedAds';

const ADS_STORAGE_KEY = 'pitesti_bazar_ads_v4';
const USERS_STORAGE_KEY = 'pitesti_bazar_users_v2';
const CURRENT_USER_KEY = 'pitesti_bazar_current_user_v2';
const ADMIN_CONFIG_KEY = 'pitesti_bazar_admin_config_v2';
const ADMIN_SESSION_KEY = 'pitesti_bazar_admin_session_v2';
const FAVORITES_STORAGE_KEY = 'pitesti_bazar_favorites_v3';
const STATS_STORAGE_KEY = 'pitesti_bazar_stats_v2';
const REPORTS_STORAGE_KEY = 'pitesti_bazar_reports_v1';
const BLACKLIST_STORAGE_KEY = 'pitesti_bazar_blacklist_v1';

// Seed users for demonstration and testing
export const INITIAL_USERS: User[] = [
  {
    id: 'user-1',
    name: 'Ionel Popescu',
    phone: '0744321890',
    password: 'ionel123',
    city: 'Pitești',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 30).toISOString(),
    isBlocked: false,
    isVerifiedSeller: true, // Has > 3 ads
  },
  {
    id: 'user-2',
    name: 'Elena Marinescu',
    phone: '0721554321',
    password: 'elena123',
    city: 'Pitești',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 15).toISOString(),
    isBlocked: false,
    isVerifiedSeller: true,
  },
  {
    id: 'user-3',
    name: 'Andrei Diaconu',
    phone: '0765432109',
    password: 'andrei123',
    city: 'Mioveni',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 8).toISOString(),
    isBlocked: false,
    isVerifiedSeller: false,
  },
  {
    id: 'user-4',
    name: 'Radu Bârloiu',
    phone: '0730987654',
    password: 'radu123',
    city: 'Curtea de Argeș',
    createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(),
    isBlocked: false,
    isVerifiedSeller: false,
  },
];

// Seed sample reports for admin demonstration
export const INITIAL_REPORTS: AdReport[] = [
  {
    id: 'rep-1',
    adId: 'ad-3',
    adTitle: 'iPhone 14 Pro 128GB Deep Purple, fără urme',
    sellerName: 'Andrei Diaconu',
    sellerPhone: '0765432109',
    reason: 'Preț suspect de mic pentru acest model',
    details: 'Mi s-a părut că prețul este cu 1000 lei mai jos decât piața, verificați dacă e original.',
    reporterPhone: '0722998877',
    createdAt: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
    isResolved: false,
  }
];

// --- REPORTS MANAGEMENT ---
export function getStoredReports(): AdReport[] {
  try {
    const raw = localStorage.getItem(REPORTS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(INITIAL_REPORTS));
      return INITIAL_REPORTS;
    }
    return JSON.parse(raw) || [];
  } catch {
    return INITIAL_REPORTS;
  }
}

export function saveStoredReports(reports: AdReport[]): void {
  try {
    localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(reports));
  } catch (err) {
    console.error('Error saving reports', err);
  }
}

// --- BLACKLIST MANAGEMENT ---
export function getBlacklistedPhones(): BlacklistedPhone[] {
  try {
    const raw = localStorage.getItem(BLACKLIST_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveBlacklistedPhones(list: BlacklistedPhone[]): void {
  try {
    localStorage.setItem(BLACKLIST_STORAGE_KEY, JSON.stringify(list));
  } catch (err) {
    console.error('Error saving blacklisted phones', err);
  }
}

export function isPhoneBlacklisted(phone: string): boolean {
  const clean = cleanPhone(phone);
  const list = getBlacklistedPhones();
  return list.some((b) => cleanPhone(b.phone) === clean);
}

export function addBlacklistPhone(phone: string, name: string | undefined, reason: string): void {
  const list = getBlacklistedPhones();
  const clean = cleanPhone(phone);
  if (!list.some((b) => cleanPhone(b.phone) === clean)) {
    const updated = [
      {
        phone,
        name,
        reason,
        blockedAt: new Date().toISOString(),
      },
      ...list,
    ];
    saveBlacklistedPhones(updated);
  }
}

export function removeBlacklistPhone(phone: string): void {
  const clean = cleanPhone(phone);
  const list = getBlacklistedPhones();
  const updated = list.filter((b) => cleanPhone(b.phone) !== clean);
  saveBlacklistedPhones(updated);
}

// --- USERS MANAGEMENT ---
export function getStoredUsers(): User[] {
  try {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(INITIAL_USERS));
      return INITIAL_USERS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : INITIAL_USERS;
  } catch {
    return INITIAL_USERS;
  }
}

export function saveStoredUsers(users: User[]): void {
  try {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  } catch (err) {
    console.error('Error saving users', err);
  }
}

export function getCurrentUser(): User | null {
  try {
    const raw = localStorage.getItem(CURRENT_USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setCurrentUser(user: User | null): void {
  try {
    if (user) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(CURRENT_USER_KEY);
    }
  } catch (err) {
    console.error('Error setting current user', err);
  }
}

// --- ADMIN MANAGEMENT ---
export function getAdminConfig(): AdminConfig {
  const defaultConfig: AdminConfig = {
    isConfigured: false,
    email: 'MarianNiculescu59@gmail.com',
    phone: '0722123456',
    password: '',
    promoPrice: 5,
    totalRevenue: 25,
  };

  try {
    const raw = localStorage.getItem(ADMIN_CONFIG_KEY);
    if (!raw) return defaultConfig;
    return { ...defaultConfig, ...JSON.parse(raw) };
  } catch {
    return defaultConfig;
  }
}

export function saveAdminConfig(config: AdminConfig): void {
  try {
    localStorage.setItem(ADMIN_CONFIG_KEY, JSON.stringify(config));
  } catch (err) {
    console.error('Error saving admin config', err);
  }
}

export function isAdminLoggedIn(): boolean {
  try {
    return localStorage.getItem(ADMIN_SESSION_KEY) === 'true';
  } catch {
    return false;
  }
}

export function setAdminLoggedIn(status: boolean): void {
  try {
    if (status) {
      localStorage.setItem(ADMIN_SESSION_KEY, 'true');
    } else {
      localStorage.removeItem(ADMIN_SESSION_KEY);
    }
  } catch (err) {
    console.error('Error setting admin session', err);
  }
}

// --- ADS MANAGEMENT ---
export function getStoredAds(): Ad[] {
  try {
    const raw = localStorage.getItem(ADS_STORAGE_KEY);
    if (!raw) {
      const mapped: Ad[] = INITIAL_ADS.map((ad, idx) => ({
        ...ad,
        userId: INITIAL_USERS[idx % INITIAL_USERS.length]?.id || 'user-1',
        isPromoted: idx === 0 || idx === 1,
        status: 'approved', // Seed ads are all approved by default
        reportsCount: idx === 2 ? 1 : 0,
      }));
      localStorage.setItem(ADS_STORAGE_KEY, JSON.stringify(mapped));
      return mapped;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : INITIAL_ADS;
  } catch {
    return INITIAL_ADS;
  }
}

export function saveStoredAds(ads: Ad[]): void {
  try {
    localStorage.setItem(ADS_STORAGE_KEY, JSON.stringify(ads));
  } catch (err) {
    console.error('Error saving ads', err);
  }
}

export function resetStoredAdsToDefault(): Ad[] {
  const mapped: Ad[] = INITIAL_ADS.map((ad, idx) => ({
    ...ad,
    userId: INITIAL_USERS[idx % INITIAL_USERS.length]?.id || 'user-1',
    isPromoted: idx === 0 || idx === 1,
    status: 'approved',
    reportsCount: 0,
  }));
  localStorage.setItem(ADS_STORAGE_KEY, JSON.stringify(mapped));
  localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(INITIAL_USERS));
  localStorage.setItem(REPORTS_STORAGE_KEY, JSON.stringify(INITIAL_REPORTS));
  localStorage.setItem(BLACKLIST_STORAGE_KEY, JSON.stringify([]));
  return mapped;
}

// Check if a seller has > 3 ads approved
export function isUserVerifiedSeller(userIdOrPhone: string, ads: Ad[], users: User[]): boolean {
  const user = users.find((u) => u.id === userIdOrPhone || u.phone === userIdOrPhone);
  if (user && user.isVerifiedSeller) return true;

  const clean = cleanPhone(userIdOrPhone);
  const userApprovedAds = ads.filter((a) => 
    a.status === 'approved' && 
    (a.userId === userIdOrPhone || cleanPhone(a.phone) === clean)
  );
  return userApprovedAds.length >= 3;
}

// --- STATS MANAGEMENT ---
export function getDailyStats(): DailyStats {
  const todayStr = new Date().toISOString().split('T')[0];
  try {
    const raw = localStorage.getItem(STATS_STORAGE_KEY);
    if (!raw) {
      const initial: DailyStats = {
        visitorsToday: 154,
        lastVisitDate: todayStr,
      };
      localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(initial));
      return initial;
    }
    const stats: DailyStats = JSON.parse(raw);
    if (stats.lastVisitDate !== todayStr) {
      stats.visitorsToday = 1;
      stats.lastVisitDate = todayStr;
      localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(stats));
    }
    return stats;
  } catch {
    return { visitorsToday: 154, lastVisitDate: todayStr };
  }
}

export function incrementVisitors(): number {
  const stats = getDailyStats();
  stats.visitorsToday += 1;
  try {
    localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(stats));
  } catch {}
  return stats.visitorsToday;
}

// --- FAVORITES ---
export function getFavorites(): string[] {
  try {
    const raw = localStorage.getItem(FAVORITES_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveFavorites(favs: string[]): void {
  try {
    localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favs));
  } catch {}
}

// --- FORMATTERS ---
export function formatPrice(price: number, currency: 'lei' | '€', isFree?: boolean): string {
  if (isFree || price === 0) {
    return 'Gratuit';
  }
  const formatted = price.toLocaleString('ro-RO');
  return `${formatted} ${currency}`;
}

export function formatTimeAgo(isoString: string): string {
  try {
    const date = new Date(isoString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMin = Math.floor(diffMs / (1000 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMin < 1) return 'Chiar acum';
    if (diffMin < 60) return `Acum ${diffMin} min`;

    const isToday = date.toDateString() === now.toDateString();
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    if (isToday) {
      return `Azi la ${hours}:${minutes}`;
    }

    const yesterday = new Date(now);
    yesterday.setDate(now.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) {
      return `Ieri la ${hours}:${minutes}`;
    }

    if (diffDays < 7) {
      return `Acum ${diffDays} zile`;
    }

    return date.toLocaleDateString('ro-RO', { day: 'numeric', month: 'short' });
  } catch {
    return 'Recent';
  }
}

export function cleanPhone(phone: string): string {
  return phone.replace(/[^\d]/g, '');
}

export function cleanPhoneForWhatsApp(phone: string): string {
  let cleaned = phone.replace(/[^\d+]/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = '4' + cleaned;
  }
  if (!cleaned.startsWith('+') && !cleaned.startsWith('40')) {
    cleaned = '40' + cleaned;
  }
  return cleaned.replace('+', '');
}
